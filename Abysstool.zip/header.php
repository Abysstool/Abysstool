 
<?php

// Determine current page for navigation
$current_page = basename($_SERVER['PHP_SELF'], '.php');

// Navigation data with page identifiers
$navData = [
    ['id' => 'home', 'text' => 'Home', 'page_id' => 'index', 'type' => 'internal', 'url' => '/index'],
    ['id' => 'tools', 'text' => 'Tools', 'page_id' => 'tools', 'type' => 'internal', 'url' => '/tools'],
     ['id' => 'disclaimer', 'text' => 'Disclaimer', 'page_id' => 'disclaimer', 'type' => 'internal', 'url' => '/disclaimer'],
      ['id' => 'privacy', 'text' => 'Privacy', 'page_id' => 'privacy', 'type' => 'internal', 'url' => '/privacy'],
   ['id' => 'terms', 'text' => 'Terms', 'page_id' => 'terms', 'type' => 'internal', 'url' => '/terms'],
    ['id' => 'about', 'text' => 'ABOUT', 'page_id' => 'about', 'type' => 'internal', 'url' => '/about']];
 

/* [
        'id' => 'LegalPage',
        'text' => 'LegalPage',
        'page_id' => 'LegalPage',
        'type' => 'dropdown',
        'items' => [
 
            ['text' => 'Blog', 'url' => 'blog.php', 'external' => false],
            ['text' => 'Documentation', 'url' => 'https://docs.abysstools.com', 'external' => true],
            ['text' => 'Community Forum', 'url' => 'https://forum.abysstools.com', 'external' => true],
            ['text' => 'GitHub', 'url' => 'https://github.com/abysstools', 'external' => true]
        ]
    ], */
   /* ['id' => 'blog', 'text' => 'BLOG', 'page_id' => 'blog', 'type' => 'internal', 'url' => 'blog.php']
];*/
?>

<!-- Header with Logo and Navigation -->
<header>

    <a href="index.php" class="logo"><span class="highlight">Abysstool</span></a>


    <nav id="navbar">
        <?php foreach ($navData as $item): ?>
            <?php if ($item['type'] === 'dropdown'): ?>
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link <?php echo ($current_page === $item['page_id']) ? 'active' : ''; ?>">
                        <?php echo $item['text']; ?> <i class="fas fa-chevron-down dropdown-icon"></i>
                    </a>
                    <div class="dropdown-menu">
                        <?php foreach ($item['items'] as $dropdownItem): ?>
                            <a href="<?php echo $dropdownItem['url']; ?>" 
                               class="dropdown-item <?php echo $dropdownItem['external'] ? 'external-link' : ''; ?>"
                               <?php echo $dropdownItem['external'] ? 'target="_blank" rel="noopener noreferrer"' : ''; ?>>
                               <?php echo $dropdownItem['text']; ?>
                               <?php if ($dropdownItem['external']): ?>
                                   <i class="fas fa-external-link-alt external-icon"></i>
                               <?php endif; ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php else: ?>
                <a href="<?php echo $item['url']; ?>" 
                   class="nav-link <?php echo ($current_page === $item['page_id']) ? 'active' : ''; ?>"
                   <?php echo $item['type'] === 'external' ? 'target="_blank" rel="noopener noreferrer"' : ''; ?>>
                   <?php echo $item['text']; ?>
                   <?php if ($item['type'] === 'external'): ?>
                       <i class="fas fa-external-link-alt external-icon"></i>
                   <?php endif; ?>
                </a>
            <?php endif; ?>
        <?php endforeach; ?>
    </nav>
    
    <div class="hamburger" id="hamburger">
        <span></span>
        <span></span>
        <span></span>
    </div>

</header