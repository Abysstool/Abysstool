
<link rel="icon" type="image/png" href="/assets/favicon-96x96.png" sizes="96x96" />
<link rel="icon" type="image/svg+xml" href="/assets/favicon.svg" />
<link rel="shortcut icon" href="/assets/favicon.ico" />
<link rel="apple-touch-icon" sizes="180x180" href="/assets/apple-touch-icon.png" />

<meta name="apple-mobile-web-app-title" content="AbyssTool" />
<link rel="manifest" href="/assets/site.webmanifest" />
<meta name="robots" content="max-image-preview:large">
<?php
// --- Canonical URL Generation ---
// This code automatically creates the full, correct URL for the current page.
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
$host = $_SERVER['HTTP_HOST'];
$uri = $_SERVER['REQUEST_URI'];

// Clean up the URI to ensure it points to the .php-less version
$clean_uri = strtok($uri, '?');

$canonicalUrl = $protocol . "://" . $host . $clean_uri;
?>
<link rel="canonical" href="<?php echo htmlspecialchars($canonicalUrl); ?>" />

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-XNQP7VND1K"></script>
<script>
  window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
        gtag('config', 'G-XNQP7VND1K');
        </script>