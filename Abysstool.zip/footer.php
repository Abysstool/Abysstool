 <?php
// Determine the current page to highlight the active link
$current_page = basename($_SERVER['PHP_SELF'], '.php');

// Footer data
$footerData = [
    'col1Title' => 'AbyssTool',
    'col1Content' => 'Digital privacy tools that respect your data. No tracking, no data collection, just pure utility from the depths of the abyss.',
    'col2Title' => 'Quick Links',
    'col2Items' => [
        ['text' => 'Home', 'url' => '/index', 'page_id' => 'index'],
        ['text' => 'Tools', 'url' => '/tools', 'page_id' => 'tools'],
        ['text' => 'Disclaimer', 'url' => '/disclaimer', 'page_id' => 'disclaimer'],
        ['text' => 'Privacy', 'url' => '/privacy', 'page_id' => 'privacy'],
        ['text' => 'Terms', 'url' => '/terms', 'page_id' => 'terms'],
        ['text' => 'About', 'url' => '/about', 'page_id' => 'about']
            

    ],
    'col4Title' => 'Important Notice',
    'col4Content' => 'While abysstool itself collects <strong>zero user data</strong>, please be aware that third-party advertising networks may collect data through ads displayed on this site.',
    'col4Content2' => 'For maximum privacy, we recommend using ad-blockers or privacy-focused browsers when accessing our tools.'
];

// Set current year for footer
$currentYear = date("2025");
?>

<!-- Footer -->
<footer>
    <div class="footer-content">
        <div class="footer-column">
            <h3><?php echo $footerData['col1Title']; ?></h3>
            <p><?php echo $footerData['col1Content']; ?></p>
            <div class="privacy-badge" style="margin-top: 0.9rem;">
                <i class="fas fa-shield-alt"></i> Privacy First Since 2025
            </div>
        </div>
        
        <div class="footer-column">
            <h3><?php echo $footerData['col2Title']; ?></h3>
            <ul>
                <?php foreach ($footerData['col2Items'] as $item): ?>
                    <?php
                        // Check if the current link's page ID matches the current page
                        $isActive = ($current_page === $item['page_id']);
                        // If it's active, apply an inline style to make it look like the nav links
                        $activeStyle = $isActive ? 'style="color: var(--primary-light); transform: translateX(5px);"' : '';
                    ?>
                    <li><a href="<?php echo $item['url']; ?>" <?php echo $activeStyle; ?>><i class="fas fa-angle-right" style="margin-right: 8px;"></i> <?php echo $item['text']; ?></a></li>
                <?php endforeach; ?>
            </ul>
        </div>
        
        <div class="footer-column">
            <h3><?php echo $footerData['col4Title']; ?></h3>
            <p style="color: #c5c5c5; font-size: 0.95rem; line-height: 1.65;">
                <?php echo $footerData['col4Content']; ?>
            </p>
            <p style="color: #c5c5c5; font-size: 0.95rem; line-height: 1.65; margin-top: 0.9rem;">
                <?php echo $footerData['col4Content2']; ?>
            </p>
        </div>
    </div>
    
    <div class="footer-bottom">
        <p>&copy; <span id="year"><?php echo $currentYear; ?></span> abysstool - All rights reserved in the abyss. <strong style="color: var(--primary-light);">No user data is collected by abysstool.</strong></p>
        <p style="margin-top: 0.6rem; font-size: 0.85rem; color: #7a7a7a;">
            Disclaimer: While we take privacy seriously, third-party ads may collect data. Use ad-blockers for complete privacy protection.
        </p>
    </div>
</footer