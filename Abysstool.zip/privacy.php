 <?php
// Set current year for footer
$currentYear = date("2025");
// Determine current page for navigation
$current_page = basename($_SERVER['PHP_SELF'], '.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include 'head.php'; ?> 
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="AbyssTools - Privacy Policy outlining our commitment to user privacy and data protection while using our free online tools.">
    <meta name="keywords" content="privacy policy, digital privacy, data protection, zero data collection, no tracking, secure tools, privacy tools, online privacy">
    <meta name="author" content="AbyssTool Team">
    <meta name="robots" content="index, follow">
    <meta property="og:type" content="website">
    <meta property="og:title" content="Privacy Policy - AbyssTools | Zero Data Collection">
    <meta property="og:description" content="Our commitment to absolute privacy. AbyssTools collects zero user data and ensures your information remains yours alone.">
    <meta property="og:url" content="https://abysstool.42web.io/privacy">
    <meta property="og:image" content="https://abysstool.42web.io/privacy-policy.png">
    <meta property="og:site_name" content="AbyssTools">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Privacy Policy - AbyssTools | Zero Data Collection">
    <meta name="twitter:description" content="Our commitment to absolute privacy. AbyssTools collects zero user data and ensures your information remains yours alone.">
    <meta name="twitter:image" content="https://abysstool.42web.io/privacy-policy.png">
    <title>AbyssTool - Privacy</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
<style>
/* Add this to your existing style.css file */

/* Privacy Page Specific Styles */
.privacy-page .privacy-hero {
    margin-bottom: 3.5rem;
    padding: 2.5rem;
    background: var(--card-bg);
    border-radius: var(--border-radius-lg);
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    box-shadow: var(--shadow-md);
    border: 1px solid var(--card-border);
    position: relative;
    overflow: hidden;
}

.privacy-page .privacy-hero::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(120deg, rgba(255, 0, 0, 0.05) 0%, transparent 100%);
    z-index: 0;
}

.privacy-page .privacy-hero h1 {
    color: var(--primary-light);
    margin-bottom: 1.2rem;
    font-size: 2.8rem;
    position: relative;
    z-index: 1;
}

.privacy-page .privacy-hero p {
    font-size: 1.2rem;
    line-height: 1.7;
    max-width: 800px;
    position: relative;
    z-index: 1;
}

.privacy-page .privacy-content {
    margin: 2.5rem 0;
}

.privacy-page .privacy-container {
    max-width: 900px;
    margin: 0 auto;
    background: var(--card-bg);
    border-radius: var(--border-radius-lg);
    padding: 2.8rem;
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    border: 1px solid var(--card-border);
    position: relative;
    overflow: hidden;
}

.privacy-page .privacy-container::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(120deg, rgba(255, 0, 0, 0.03) 0%, transparent 100%);
    z-index: 0;
    opacity: 0;
    transition: var(--transition);
}

.privacy-page .privacy-container:hover::before {
    opacity: 1;
}

.privacy-page h2 {
    color: var(--primary-light);
    margin: 2.2rem 0 1.4rem;
    font-size: 1.9rem;
    position: relative;
    padding-left: 1.2rem;
}

.privacy-page h2::before {
    content: '';
    position: absolute;
    left: 0;
    top: 50%;
    transform: translateY(-50%);
    height: 60%;
    width: 4px;
    background: linear-gradient(to bottom, var(--primary), var(--primary-dark));
    border-radius: 2px;
}

.privacy-page h3 {
    color: var(--primary);
    margin: 1.4rem 0 0.9rem;
    font-size: 1.5rem;
}

.privacy-page p {
    line-height: 1.75;
    margin-bottom: 1.3rem;
    font-size: 1.05rem;
    color: var(--text-secondary);
}

.privacy-page .privacy-highlights {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 1.8rem;
    margin: 2.2rem 0;
}

.privacy-page .highlight-card {
    background: rgba(25, 0, 0, 0.6);
    border: 1px solid rgba(128, 0, 0, 0.3);
    border-radius: var(--border-radius-md);
    padding: 1.8rem;
    transition: var(--transition);
    position: relative;
    overflow: hidden;
}

.privacy-page .highlight-card::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(120deg, rgba(255, 0, 0, 0.03) 0%, transparent 100%);
    z-index: 0;
    opacity: 0;
    transition: var(--transition);
}

.privacy-page .highlight-card:hover {
    transform: translateY(-3px);
    box-shadow: var(--shadow-md);
    border-color: var(--primary);
}

.privacy-page .highlight-card:hover::before {
    opacity: 1;
}

.privacy-page .highlight-card i {
    font-size: 2.2rem;
    color: var(--primary);
    margin-bottom: 1rem;
    display: block;
}

.privacy-page .highlight-card h3 {
    color: var(--primary-light);
    margin-bottom: 0.8rem;
    font-size: 1.4rem;
}

.privacy-page .privacy-list {
    padding-left: 1.7rem;
    margin: 1.6rem 0;
}

.privacy-page .privacy-list li {
    margin-bottom: 0.9rem;
    line-height: 1.75;
    position: relative;
    padding-left: 1.2rem;
}

.privacy-page .privacy-list li::before {
    content: "•";
    position: absolute;
    left: 0;
    color: var(--primary);
    font-weight: bold;
}

.privacy-page .privacy-list strong {
    color: var(--primary-light);
}

.privacy-page .privacy-commitment {
    background: rgba(128, 0, 0, 0.1);
    border-left: 3px solid var(--primary);
    border-radius: 0 var(--border-radius-md) var(--border-radius-md) 0;
    padding: 1.8rem;
    margin: 3rem 0 0;
    position: relative;
    overflow: hidden;
}

.privacy-page .privacy-commitment::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(120deg, rgba(255, 0, 0, 0.05) 0%, transparent 100%);
    z-index: 0;
}

.privacy-page .privacy-commitment h3 {
    color: var(--primary-light);
    margin-bottom: 1rem;
    font-size: 1.7rem;
    position: relative;
    z-index: 1;
}

.privacy-page .privacy-commitment p {
    font-size: 1.1rem;
    position: relative;
    z-index: 1;
}

.privacy-page a {
    color: var(--primary-light);
    text-decoration: none;
    transition: var(--transition);
    position: relative;
}

.privacy-page a::after {
    content: '';
    position: absolute;
    bottom: 2px;
    left: 0;
    width: 0;
    height: 1px;
    background: var(--primary-light);
    transition: var(--transition);
}

.privacy-page a:hover {
    color: var(--primary);
}

.privacy-page a:hover::after {
    width: 100%;
}
</style>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebPage",
  "@id": "https://abysstool.42web.io/Privacy",
  "url": "https://abysstool.42web.io/Privacy",
  "name": "Privacy Policy - Abysstool",
  "isPartOf": {
    "@id": "https://abysstool.42web.io/#website"
  },
  "about": "Privacy Policy",
  "description": "This Privacy Policy page explains how Abysstool collects, uses, and protects your data when you use its free online tools.",
  "breadcrumb": {
    "@type": "BreadcrumbList",
    "itemListElement": [
      {
        "@type": "ListItem",
        "position": 1,
        "name": "Home",
        "item": "https://abysstool.42web.io/"
      },
      {
        "@type": "ListItem",
        "position": 2,
        "name": "Privacy Policy",
        "item": "https://abysstool.42web.io/Privacy"
      }
    ]
  }
}
</script>
</head>
<body>
    <?php include 'header.php'; ?>

    <!-- Main Content -->
    <main class="main-content privacy-page">
        <div class="content">
            <section class="privacy-hero animate-on-scroll">
                <h1>Our Privacy <span class="highlight">Commitment</span></h1>
                <p>At AbyssTools, your privacy isn't just a policy—it's our oath. We've built our platform on the foundation of absolute privacy, where your data remains yours alone.</p>
            </section>
           
            <section class="privacy-content animate-on-scroll">
                <div class="privacy-container">
                    <h2>Zero Data Collection</h2>
                    <p>We don't collect, store, or process your personal information or usage data. Unlike most free tools that monetize your data, we operate differently:</p>
                    
                    <div class="privacy-highlights">
                        <div class="highlight-card">
                            <i class="fas fa-shield-alt"></i>
                            <h3>Local Processing</h3>
                            <p>Most tools work entirely in your browser - your data never leaves your device. We don't have servers to store your information because we never receive it.</p>
                        </div>
                        
                        <div class="highlight-card">
                            <i class="fas fa-ban"></i>
                            <h3>No Hidden Trackers</h3>
                            <p>We don't embed third-party analytics, cookies, or tracking scripts in our tools. What you see is what you get - no hidden surveillance.</p>
                        </div>
                        
                        <div class="highlight-card">
                            <i class="fas fa-code"></i>
                            <h3>Transparent Code</h3>
                            <p>Our open-source tools allow security experts to verify our privacy claims. You can see exactly what our tools do - and don't do.</p>
                        </div>
                    </div>
                    
                    <h2>What We Don't Collect</h2>
                    <p>AbyssTools is designed to work without collecting any of your personal information:</p>
                    <ul class="privacy-list">
                        <li><strong>No Personal Identifiers:</strong> We don't collect your name, email, IP address, or any information that could identify you.</li>
                        <li><strong>No Usage Data:</strong> We don't track which tools you use, how you use them, or what inputs you provide.</li>
                        <li><strong>No Browsing History:</strong> We don't monitor your navigation through our site or track your activity across pages.</li>
                        <li><strong>No Device Information:</strong> While standard server logs may capture basic technical information (like browser type), we don't store or use this data to identify you.</li>
                    </ul>
                    
                <h2>Third-Party Services: Analytics and Advertising</h2>
                <p>To support and improve our free services, AbyssTool uses third-party services from Google. It is important for you to understand how these services work and what data they may collect. Our commitment to collecting zero data applies to the AbyssTool website itself, not to these integrated third-party services.</p>

                <h3>1. Google Analytics</h3>
                <p>We use Google Analytics to understand how visitors engage with our website. This helps us improve our tools and user experience. Google Analytics collects data such as:</p>
                <ul class="privacy-list">
                    <li>Your IP address (often anonymized)</li>
                        <li>Your general geographic location</li>
                            <li>Your browser type and device</li>
                                <li>The pages you visit on our site and the time you spend on them</li>
                                </ul>
                                <p>This data is aggregated and does not personally identify you to us. For more information, you can review <a href="https://policies.google.com/technologies/partner-sites" target="_blank" rel="noopener noreferrer">Google's Privacy & Terms</a>. You can also opt out of Google Analytics by installing the <a href="https://tools.google.com/dlpage/gaoptout" target="_blank" rel="noopener noreferrer">Google Analytics Opt-out Browser Add-on</a>.</p>

                                <h3>2. Google AdSense</h3>
                                <p>This website displays advertisements from Google AdSense to help cover the costs of running this free service. Google and its partners use cookies (such as the DoubleClick cookie) to serve ads based on your prior visits to this and other websites on the internet.</p>
                                <p>This allows them to display personalized advertisements that may be more relevant to you. You can opt out of personalized advertising by visiting your <a href="https://adssettings.google.com/authenticated" target="_blank" rel="noopener noreferrer">Google Ad Settings</a> page. Alternatively, you can opt out of a third-party vendor's use of cookies for personalized advertising by visiting <a href="http://www.aboutads.info/choices/" target="_blank" rel="noopener noreferrer">www.aboutads.info</a>.</p>
                    
                    <div class="privacy-badge" style="margin: 2.2rem 0; display: inline-block;">
                        <i class="fas fa-shield-alt"></i> Your Privacy, Our Oath
                    </div>
                    
                    <h2>How Our Tools Work Without Collecting Data</h2>
                    <p>Our tools are designed to function entirely within your browser:</p>
                    <ul class="privacy-list">
                        <li><strong>Client-Side Processing:</strong> All computations happen in your browser using JavaScript. Your data never leaves your device.</li>
                        <li><strong>No Server Communication:</strong> Most tools don't make any network requests - everything happens locally on your machine.</li>
                        <li><strong>Open Source Verification:</strong> You can inspect the code to verify that no data is being transmitted.</li>
                        <li><strong>Transparent Operations:</strong> We clearly explain what each tool does and doesn't do with your data.</li>
                    </ul>
                    
                    <h2>Third-Party Services</h2>
                    <p>While we strive to minimize external dependencies, some tools may use:</p>
                    <ul class="privacy-list">
                        <li><strong>Google Fonts:</strong> For consistent typography across devices. This is a standard web practice that doesn't track individual users.</li>
                        <li><strong>Font Awesome:</strong> For icons used in our interface. Again, this is standard practice that doesn't collect personal information.</li>
                    </ul>
                    
                    <h2>Changes to This Policy</h2>
                    <p>We may update this Privacy Policy from time to time. Any changes will be posted here with the updated effective date. We encourage you to review this policy periodically.</p>
                    
                    <h2>Contact Us</h2>
                    <p>If you have any questions about our privacy practices, please contact us through our <a href="contact.php">Contact Page</a>.</p>
                    
                    <div class="privacy-commitment">
                        <h3>Our Privacy Pledge</h3>
                        <p>We believe that privacy is a fundamental human right, not a premium feature. In a world of constant surveillance, we're committed to providing tools that respect your autonomy and keep your data under your control. When you use AbyssTools, you're not just using a utility—you're taking a stand for digital rights in an increasingly monitored world.</p>
                    </div>
                </div>
            </section>
        </div>
    </main>
    
    <?php include 'footer.php'; ?>
    
    <!-- Live Background -->
    <canvas id="horror-canvas"></canvas>
    <div id="scan-lines"></div>
    <div id="glitch-overlay"></div>
    
    <script src="style.js"></script>
</body>
</html