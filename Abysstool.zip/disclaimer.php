 <?php
// Set current year for footer
$currentYear = date("2025");
// Determine current page for navigation
$current_page = basename($_SERVER['PHP_SELF'], '.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include 'head.php'; ?> 
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="ToolVerse - Disclaimer outlining the limitations of liability and usage terms for our free online tools.">
    <meta name="keywords" content="ToolVerse, disclaimer, online tools, no warranties, limitation of liability, external links, ads, terms of service">
    <meta name="author" content="ToolVerse Team">
    <meta name="robots" content="index, follow">
    <meta property="og:title" content="ToolVerse - Disclaimer">
    <meta property="og:description" content="Read ToolVerse's Disclaimer to understand the limitations of liability and usage terms while using our platform.">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://abysstool.42web.io/disclaimer.php">
    <meta property="og:image" content="https://abysstool.42web.io/og-image.jpg">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="ToolVerse - Disclaimer">
    <meta name="twitter:description" content="Read ToolVerse's Disclaimer to understand the limitations of liability and usage terms while using our platform.">
    <meta name="twitter:image" content="https://toolverse.42web.io/twitter-image.jpg">
    
    <title>AbyssTool - Disclaimer</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebPage",
  "@id": "https://abysstool.42web.io/disclaimer",
  "url": "https://abysstool.42web.io/disclaimer",
  "name": "Disclaimer - Abysstool",
  "isPartOf": {
    "@id": "https://abysstool.42web.io/#website"
  },
  "about": "Disclaimer",
  "description": "This Disclaimer page explains the limitations of liability and conditions of use for Abysstool’s free online tools.",
  "breadcrumb": {
    "@type": "BreadcrumbList",
    "itemListElement": [
      {
        "@type": "ListItem",
        "position": 1,
        "name": "Home",
        "item": "https://abysstool.42web.io/"
      },
      {
        "@type": "ListItem",
        "position": 2,
        "name": "Disclaimer",
        "item": "https://abysstool.42web.io/disclaimer"
      }
    ]
  }
}
</script>
</head>
<body>
    <?php include 'header.php'; ?>

    <!-- Main Content -->
    <main class="main-content">
        <div class="content">
            <section class="hero animate-on-scroll">
                <h1>Disclaimer</h1>
                <p>Understanding the limitations of liability and usage terms for our free online tools</p>
            </section>
            
            <section class="seo-content animate-on-scroll">
                <div class="container">
                    <p><strong>Effective Date:</strong> 29-07-2025</p>
                    
                    <p>The information and tools provided on AbyssTool (<a href="https://abysstool.42web.io" target="_blank">https://abysstool.42web.io</a>) are for general informational and educational purposes only. While we aim to ensure the accuracy and reliability of all our tools, we make no guarantees or warranties about their correctness, suitability, or applicability to specific tasks.</p>
                    
                    <h2>1. Tool Usage</h2>
                    <p>All tools (including but not limited to calculators, converters, counters, and analyzers) on this website are provided "as-is." The results generated are based on standard formulas and logic but may not reflect real-world variations or complexities.</p>
                    
                    <p><strong>Use the tools at your own risk. Abysstool is not responsible for any consequences arising from the use or misuse of these tools.</strong></p>
                    
                    <h2>2. No Professional Advice</h2>
                    <p>Nothing on this website constitutes or is intended to be taken as:</p>
                    <ul>
                        <li>Financial advice</li>
                        <li>Legal advice</li>
                        <li>Medical advice</li>
                        <li>Technical or professional guidance</li>
                    </ul>
                    <p>Always consult a qualified expert or professional before making decisions based on the results from any tool.</p>
                    
                    <h2>3. External Links</h2>
                    <p>AbyssTool may contain links to third-party websites for convenience. We do not endorse or take responsibility for the accuracy, availability, or policies of external sites.</p>
                    
                    <h2>4. Third-Party Services (Analytics and Ads)</h2>
                    <p>This website uses Google Analytics to monitor traffic and Google AdSense to display advertisements. We do not control the data collection or content provided by these third-party services. We are not liable for any issues arising from your interaction with these services. For full details, please review our <a href="/Privacy">Privacy Policy</a>.</p>
                    
                    <h2>5. Limitation of Liability</h2>
                    <p>To the maximum extent permitted by applicable law, AbyssTool and its creators disclaim all liability for any loss, damage, or injury resulting from:</p>
                    <ul>
                        <li>The use or performance of the site</li>
                        <li>Inability to use the site</li>
                        <li>Reliance on results or content presented</li>
                    </ul>
                    
                    <h2>6. Changes to This Disclaimer</h2>
                    <p>We may update this disclaimer without prior notice. All changes will be posted on this page.</p>
                    
                    <h2>7. Contact Us</h2>
                    <p>If you have questions about this disclaimer, please reach out via the <a href="contact.php">Contact Page</a>.</p>
                    
                    <p>By using this site, you agree to this disclaimer and all its terms.</p>
                    
                    <div class="privacy-badge" style="margin-top: 2rem; max-width: 400px; margin-left: auto; margin-right: auto;">
                        <i class="fas fa-shield-alt"></i> This is not legal advice
                    </div>
                </div>
            </section>
        </div>
    </main>
    
    <?php include 'footer.php'; ?>
    
    <!-- Live Background -->
    <canvas id="horror-canvas"></canvas>
    <div id="scan-lines"></div>
    <div id="glitch-overlay"></div>
    
    <script src="style.js"></script>
</body>
</html