 <?php
// Set current page for navigation
$current_page = basename($_SERVER['PHP_SELF'], '.php');

// Tool data specific to this tool
$toolData = [
    'id' => 'image-compressor',
    'name' => 'Image Compressor',
    'description' => 'Compress JPG, PNG, and WEBP images with incredible speed. Our tool is privacy-focused and works entirely in your browser.',
    'icon' => 'fas fa-compress-arrows-alt', // Font Awesome icon
    'logoUrl' => 'https://placehold.co/40x40/800000/FFFFFF?text=IC' // Optional placeholder logo
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include '/head.php'; ?> 

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $toolData['name']; ?> - AbyssTool</title>
    
    <!-- SEO Meta Tags -->
    <meta name="description" content="AbyssTools - <?php echo $toolData['description']; ?>">
    <meta name="keywords" content="image compressor, compress image, reduce image size, privacy tool, secure image compression, no data collection, jpg compressor, png compressor">
    <meta name="author" content="AbyssTools Team">
    <meta name="robots" content="index, follow">
    <meta property="og:type" content="website">
    <meta property="og:title" content="<?php echo $toolData['name']; ?> - AbyssTool">
    <meta property="og:description" content="<?php echo $toolData['description']; ?>">
    <meta property="og:url" content="https://abysstool.42web.io/tools/<?php echo $toolData['id']; ?>">
    <meta property="og:image" content="https://abysstool.42web.io/<?php echo $toolData['id']; ?>-cover.png">
    
    <!-- CSS Links -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../style.css">

    <!-- Tool-Specific CSS -->
    <style>
        .tool-page .upload-area {
            border: 2px dashed var(--card-border); border-radius: var(--border-radius-md); padding: 2.5rem 1rem;
            margin-bottom: 1.5rem; background-color: rgba(0, 0, 0, 0.2); transition: var(--transition); cursor: pointer;
        }
        .tool-page .upload-area.dragover { background-color: rgba(255, 0, 0, 0.05); border-color: var(--primary); }
        .tool-page .upload-area input[type="file"] { display: none; }
        .tool-page .upload-area label {
            cursor: pointer; font-weight: 500; color: var(--primary-light);
            display: flex; flex-direction: column; align-items: center; gap: 0.5rem;
        }
        .tool-page .upload-area svg { width: 50px; height: 50px; stroke: var(--primary); }
        .tool-page .file-list-section { display: none; text-align: left; margin-bottom: 1.5rem; }
        .tool-page #fileCount { font-weight: 600; margin-bottom: 0.5rem; color: var(--primary-light); }
        .tool-page #fileList {
            max-height: 180px; overflow-y: auto; border: 1px solid var(--card-border);
            border-radius: var(--border-radius-sm); padding: 0.5rem; background-color: rgba(0, 0, 0, 0.2);
        }
        .tool-page .file-item {
            display: flex; justify-content: space-between; align-items: center; padding: 0.5rem 0.75rem;
            font-size: 0.9rem; background-color: var(--card-bg); border-radius: var(--border-radius-sm); margin-bottom: 0.5rem;
        }
        .tool-page .file-format { text-transform: uppercase; font-weight: 600; color: var(--primary); margin-left: 0.5rem; }
        .tool-page .file-size { font-weight: 500; color: var(--text-secondary); }
        .tool-page .progress-section { margin-top: 1.5rem; width: 100%; display: none; }
        .tool-page .progress-bar-container { width: 100%; background-color: rgba(0,0,0,0.3); border-radius: 20px; overflow: hidden; height: 12px; }
        .tool-page .progress-bar { width: 0%; height: 100%; background: linear-gradient(to right, var(--primary), var(--primary-dark)); border-radius: 20px; transition: width 0.4s ease-in-out; }
        .tool-page #progressText { margin-top: 0.5rem; font-size: 0.9rem; color: var(--text-secondary); }
        
        /* --- FIX: RE-STYLED MODAL POPUP --- */
        .modal-overlay {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background-color: rgba(0, 0, 0, 0.8);
            display: flex; justify-content: center; align-items: center;
            z-index: 10001; /* Ensures it's on top of everything */
            opacity: 0; visibility: hidden;
            transition: opacity 0.3s, visibility 0.3s;
        }
        .modal-overlay.show { opacity: 1; visibility: visible; }
        .modal-content {
            background: var(--card-bg); border: 1px solid var(--card-border);
            border-radius: var(--border-radius-lg); padding: 2rem;
            box-shadow: var(--shadow-xl);
            backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px);
            width: 90%; max-width: 600px;
            transform: scale(0.95);
            transition: transform 0.3s;
        }
        .modal-overlay.show .modal-content { transform: scale(1); }
        .modal-header {
            text-align: center; border-bottom: 1px solid var(--card-border);
            padding-bottom: 1.5rem; margin-bottom: 1.5rem;
        }
        .modal-header svg { width: 50px; height: 50px; color: var(--primary); margin-bottom: 1rem; }
        .modal-header h2 { margin: 0; font-size: 1.75rem; color: var(--primary-light); }
        .modal-body { max-height: 300px; overflow-y: auto; margin-right: -1rem; padding-right: 1rem; }
        #modalSummary { text-align: center; margin-bottom: 1.5rem; font-size: 1.05rem; color: var(--text-secondary); }
        .result-item {
            display: grid; grid-template-columns: 1fr auto; align-items: center; gap: 1rem;
            background: rgba(0, 0, 0, 0.2); padding: 0.75rem 1rem;
            border-radius: var(--border-radius-sm); margin-bottom: 0.5rem;
            border-left: 3px solid transparent; transition: border-color 0.3s;
        }
        .result-item:hover { border-left-color: var(--primary); }
        .result-item .filename { font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; color: var(--text); }
        .result-item .sizes { font-size: 0.85rem; color: var(--text-secondary); }
        .result-item .reduction { text-align: right; font-weight: 600; font-size: 1.1rem; }
        .result-item .reduction.success { color: #28a745; }
        .result-item .reduction.error { color: var(--primary-light); }
        .modal-footer { text-align: center; margin-top: 2rem; }
        
        /* FAQ Styles */
        .tool-page .faq-section { margin: 3.5rem 0; }
        .tool-page .faq-container { max-width: 800px; margin: 0 auto; }
        .tool-page .faq-item { background: var(--card-bg); border: 1px solid var(--card-border); border-radius: var(--border-radius-md); margin-bottom: 1rem; overflow: hidden; transition: var(--transition); }
        .tool-page .faq-item:hover { border-color: var(--primary); }
        .tool-page .faq-question { padding: 1.2rem; margin: 0; cursor: pointer; color: var(--primary-light); font-weight: 600; position: relative; display: flex; align-items: center; justify-content: space-between; }
        .tool-page .faq-question::after { content: "+"; font-size: 1.5rem; transition: var(--transition); }
        .tool-page .faq-item.active .faq-question::after { content: "−"; }
        .tool-page .faq-answer { padding: 0 1.2rem; max-height: 0; overflow: hidden; transition: max-height 0.3s ease-out, padding 0.3s ease; background: rgba(0, 0, 0, 0.1); }
        .tool-page .faq-item.active .faq-answer { padding: 1.2rem; max-height: 500px; }
        .tool-page .faq-answer p { color: var(--text-secondary); }
    </style>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "WebApplication",
      "@id": "https://abysstool.42web.io/tool/image-compressor",
      "url": "https://abysstool.42web.io/tool/image-compressor",
      "name": "Image Compressor - Abysstool",
      "description": "Compress JPG, PNG, and WEBP images with incredible speed. Our tool is privacy-focused and works entirely in your browser.",
      "applicationCategory": "MultimediaApplication",
      "operatingSystem": "Any",
      "offers": {
        "@type": "Offer",
        "price": "0"
      },
      "isPartOf": {
        "@id": "https://abysstool.42web.io/#website"
      }
    },
    {
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://abysstool.42web.io/" },
        { "@type": "ListItem", "position": 2, "name": "All Tools", "item": "https://abysstool.42web.io/tools" },
        { "@type": "ListItem", "position": 3, "name": "Image Compressor", "item": "https://abysstool.42web.io/tool/image-compressor" }
      ]
    },
    {
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "Are my images secure with this tool?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Absolutely. Your security is our highest priority. This tool processes all images locally in your browser. Your files are never sent to our servers or any third party, ensuring they remain completely private and under your control."
          }
        },
        {
          "@type": "Question",
          "name": "What file formats can I compress?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Our compressor supports the most common web image formats, including JPEG, PNG, WEBP, and BMP. The tool will intelligently apply the best compression techniques for each file type to achieve the optimal balance of size and quality."
          }
        },
        {
          "@type": "Question",
          "name": "Is there a limit on file size or the number of images?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "There are no hard limits imposed by us. The tool is designed to handle very large images and batch processing of many files at once. Performance will depend on your computer's processing power."
          }
        },
        {
          "@type": "Question",
          "name": "How much will my images be compressed?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "The compression ratio can be significant, often reducing file sizes by 70-90% or more. The tool is optimized to resize very large images to a web-friendly resolution and then applies quality-based compression to make the file size as small as possible without a major loss in visual quality."
          }
        },
        {
          "@type": "Question",
          "name": "Will the compressed images lose quality?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "All compression involves some trade-off between file size and quality. Our tool uses a \"lossy\" compression algorithm that is fine-tuned to remove unnecessary data that the human eye can't easily perceive, resulting in a dramatically smaller file with very little noticeable difference in quality."
          }
        },
        {
          "@type": "Question",
          "name": "How does the batch compression and ZIP download work?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "You can select multiple images at once. The tool will process them one by one, showing you the progress. Once all images are compressed, it will create a ZIP file containing all the optimized images directly in your browser, which you can then download with a single click."
          }
        }
      ]
    }
  ]
}
</script>
</head>
<body>
    <?php include '../header.php'; ?>

    <!-- Main Content -->
    <main class="main-content tool-page">
        <div class="content">
            <section class="tool-hero animate-on-scroll">
                <div class="tool-hero-content">
                    <div class="tool-icon-large">
                        <?php if ($toolData['logoUrl']): ?>
                            <img src="<?php echo $toolData['logoUrl']; ?>" alt="<?php echo $toolData['name']; ?> Logo" class="tool-logo-large">
                        <?php endif; ?>
                        <i class="<?php echo $toolData['icon']; ?>"></i>
                    </div>
                    <h1><?php echo $toolData['name']; ?></h1>
                    <p class="tool-description-large"><?php echo $toolData['description']; ?></p>
                </div>
            </section>
            
            <section class="tool-interface animate-on-scroll">
                <div class="tool-container">
                    <div class="upload-area" id="uploadArea">
                         <input type="file" id="imageInput" multiple accept="image/jpeg, image/png, image/webp, image/bmp">
                         <label for="imageInput">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="17 8 12 3 7 8"></polyline><line x1="12" y1="3" x2="12" y2="15"></line></svg>
                            <span><strong>Choose files</strong> or drag them here.</span>
                        </label>
                    </div>
                    <div class="file-list-section" id="fileListSection">
                        <h3 id="fileCount"></h3>
                        <div id="fileList"></div>
                    </div>
                    <button id="compressBtn" class="tool-btn" disabled>Compress Images</button>
                    <div class="progress-section" id="progressSection">
                        <div class="progress-bar-container"><div class="progress-bar" id="progressBar"></div></div>
                        <div id="progressText"></div>
                    </div>
                    <a id="downloadBtn" class="tool-btn" style="display: none; margin-top: 1rem; text-align:center;">Download Compressed ZIP</a>
                </div>
            </section>
            
            <section class="seo-content animate-on-scroll">
                <h2>Why Privacy Matters for Image Compression</h2>
                <p>When you upload your photos to an online service, you are trusting a third party with your data. These images can contain sensitive information, from personal moments to confidential business documents. Many "free" online compressors upload your files to their servers, where they can be stored, analyzed, or even sold. Our tool is different.</p>
                <h3>Client-Side Processing: The AbyssTools Guarantee</h3>
                <p>We use the power of your own browser to compress images. All processing happens locally on your device. This means:</p>
                <ul>
                    <li><strong>Your images are never uploaded to any server.</strong></li>
                    <li><strong>We collect zero data.</strong> Your files remain 100% private.</li>
                    <li><strong>Incredibly fast performance.</strong> By avoiding uploads and downloads, the process is significantly quicker.</li>
                    <li><strong>Works offline.</strong> Once the page has loaded, you can disconnect from the internet and continue to compress images securely.</li>
                </ul>
                <p>With AbyssTools, you get powerful image optimization without compromising your digital privacy. It's the secure way to make your images smaller for websites, emails, or storage.</p>
            </section>

            <section class="faq-section animate-on-scroll">
                <h2 class="section-title">Frequently Asked Questions</h2>
                <div class="faq-container">
                    <div class="faq-item">
                        <h3 class="faq-question">Are my images secure with this tool?</h3>
                        <div class="faq-answer">
                            <p>Absolutely. Your security is our highest priority. This tool processes all images locally in your browser. Your files are never sent to our servers or any third party, ensuring they remain completely private and under your control.</p>
                        </div>
                    </div>
                    <div class="faq-item">
                        <h3 class="faq-question">What file formats can I compress?</h3>
                        <div class="faq-answer">
                            <p>Our compressor supports the most common web image formats, including JPEG, PNG, WEBP, and BMP. The tool will intelligently apply the best compression techniques for each file type to achieve the optimal balance of size and quality.</p>
                        </div>
                    </div>
                    <div class="faq-item">
                        <h3 class="faq-question">Is there a limit on file size or the number of images?</h3>
                        <div class="faq-answer">
                            <p>There are no hard limits imposed by us. The tool is designed to handle very large images and batch processing of many files at once. Performance will depend on your computer's processing power. For best results, you can compress hundreds of images in a single batch.</p>
                        </div>
                    </div>
                    <div class="faq-item">
                        <h3 class="faq-question">How much will my images be compressed?</h3>
                        <div class="faq-answer">
                            <p>The compression ratio can be significant, often reducing file sizes by 70-90% or more. The tool is optimized to resize very large images (like photos from a modern camera) to a web-friendly resolution (1920px) and then applies quality-based compression to make the file size as small as possible without a major loss in visual quality.</p>
                        </div>
                    </div>
                    <div class="faq-item">
                        <h3 class="faq-question">Will the compressed images lose quality?</h3>
                        <div class="faq-answer">
                            <p>All compression involves some trade-off between file size and quality. Our tool uses a "lossy" compression algorithm that is fine-tuned to remove unnecessary data that the human eye can't easily perceive. The result is a dramatically smaller file with very little noticeable difference in quality for typical on-screen viewing.</p>
                        </div>
                    </div>
                     <div class="faq-item">
                        <h3 class="faq-question">How does the batch compression and ZIP download work?</h3>
                        <div class="faq-answer">
                            <p>You can select multiple images at once. The tool will process them one by one, showing you the progress. Once all images are compressed, it will create a ZIP file containing all the optimized images directly in your browser, which you can then download with a single click.</p>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </main>
    
    <!-- FIX: MODAL HTML IS NOW OUTSIDE THE MAIN CONTENT FOR PROPER LAYERING -->
    <div class="modal-overlay" id="successModal">
        <div class="modal-content">
            <div class="modal-header">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                <h2>Compression Complete</h2>
            </div>
            <div class="modal-body">
                <p id="modalSummary"></p>
                <div id="modalResults"></div>
            </div>
            <div class="modal-footer">
                <button class="tool-btn" id="modalCloseBtn">Close</button>
            </div>
        </div>
    </div>
    
    <?php include '../footer.php'; ?>
    
    <!-- Live Background Elements -->
    <canvas id="horror-canvas"></canvas>
    <div id="scan-lines"></div>
    <div id="glitch-overlay"></div>
    
    <!-- External JS Libraries -->
    <script src="https://cdn.jsdelivr.net/npm/browser-image-compression@2.0.2/dist/browser-image-compression.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jszip@3.10.1/dist/jszip.min.js"></script>
    
    <!-- Main JS file -->
    <script src="../style.js"></script>

    <!-- Tool-Specific JavaScript -->
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // Initialize FAQ accordions
            const faqQuestions = document.querySelectorAll('.faq-question');
            faqQuestions.forEach(question => {
                question.addEventListener('click', () => {
                    question.closest('.faq-item').classList.toggle('active');
                });
            });

            // --- JAVASCRIPT LOGIC ---
            const uploadArea = document.getElementById('uploadArea');
            const imageInput = document.getElementById('imageInput');
            const compressBtn = document.getElementById('compressBtn');
            const downloadBtn = document.getElementById('downloadBtn');
            const fileListSection = document.getElementById('fileListSection');
            const fileCount = document.getElementById('fileCount');
            const fileList = document.getElementById('fileList');
            const progressSection = document.getElementById('progressSection');
            const progressBar = document.getElementById('progressBar');
            const progressText = document.getElementById('progressText');
            const successModal = document.getElementById('successModal');
            const modalCloseBtn = document.getElementById('modalCloseBtn');
            const modalSummary = document.getElementById('modalSummary');
            const modalResults = document.getElementById('modalResults');

            uploadArea.addEventListener('dragover', (e) => { e.preventDefault(); uploadArea.classList.add('dragover'); });
            uploadArea.addEventListener('dragleave', () => uploadArea.classList.remove('dragover'));
            uploadArea.addEventListener('drop', (e) => {
                e.preventDefault();
                uploadArea.classList.remove('dragover');
                imageInput.files = e.dataTransfer.files;
                handleFileSelection();
            });

            imageInput.addEventListener('change', handleFileSelection);

            function handleFileSelection() {
                const files = imageInput.files;
                if (files.length === 0) {
                    fileListSection.style.display = 'none';
                    compressBtn.disabled = true;
                    return;
                }
                fileListSection.style.display = 'block';
                compressBtn.disabled = false;
                fileCount.textContent = `${files.length} Image(s) Selected:`;
                fileList.innerHTML = '';
                Array.from(files).forEach(file => {
                    const ext = file.name.split('.').pop() || 'unknown';
                    const item = document.createElement('div');
                    item.className = 'file-item';
                    item.innerHTML = `<span class="file-details">${file.name}<span class="file-format">${ext}</span></span><span class="file-size">${formatBytes(file.size)}</span>`;
                    fileList.appendChild(item);
                });
            }

            compressBtn.addEventListener('click', async () => {
                const files = imageInput.files;
                if (files.length === 0) return;

                compressBtn.disabled = true;
                compressBtn.innerHTML = 'Compressing... <i class="fas fa-spinner fa-spin"></i>';
                downloadBtn.style.display = 'none';
                progressSection.style.display = 'block';
                progressBar.style.width = '0%';
                progressText.textContent = '';
                
                const zip = new JSZip();
                const results = [];
                
                const options = {
                    maxWidthOrHeight: 1920,
                    maxSizeMB: 1,
                    useWebWorker: true,
                };
                
                for (let i = 0; i < files.length; i++) {
                    const file = files[i];
                    progressText.textContent = `Processing image ${i + 1} of ${files.length}: ${file.name}`;
                    try {
                        const compressedFile = await imageCompression(file, options);
                        const reduction = Math.round(((file.size - compressedFile.size) / file.size) * 100);
                        zip.file(compressedFile.name, compressedFile);
                        results.push({
                            name: file.name, success: true, originalSize: file.size,
                            newSize: compressedFile.size, reduction: reduction
                        });
                    } catch (error) {
                        console.error(`Failed to compress ${file.name}:`, error);
                        results.push({ name: file.name, success: false, error: error.message });
                    }
                    const progress = Math.round(((i + 1) / files.length) * 100);
                    progressBar.style.width = `${progress}%`;
                }

                progressText.textContent = 'Creating ZIP file...';
                const zipBlob = await zip.generateAsync({ type: "blob" });
                const downloadUrl = URL.createObjectURL(zipBlob);
                downloadBtn.href = downloadUrl;
                downloadBtn.download = 'abysstools-compressed-images.zip';
                downloadBtn.style.display = 'block';

                compressBtn.disabled = false;
                compressBtn.innerHTML = 'Compress More Images';
                progressSection.style.display = 'none';
                showSuccessPopup(results, zipBlob.size);
            });
            
            function showSuccessPopup(results, totalZipSize) {
                const successCount = results.filter(r => r.success).length;
                modalSummary.textContent = `Successfully compressed ${successCount} of ${results.length} images. Total ZIP size: ${formatBytes(totalZipSize)}.`;
                modalResults.innerHTML = '';
                results.forEach(res => {
                    const item = document.createElement('div');
                    item.className = 'result-item';
                    if (res.success) {
                        item.innerHTML = `
                            <div>
                                <p class="filename">${res.name}</p>
                                <p class="sizes">
                                    ${formatBytes(res.originalSize)} &rarr; ${formatBytes(res.newSize)}
                                </p>
                            </div>
                            <p class="reduction success">-${res.reduction}%</p>
                        `;
                    } else {
                        item.innerHTML = `
                            <div><p class="filename">${res.name}</p></div>
                            <p class="reduction error">Failed</p>
                        `;
                    }
                    modalResults.appendChild(item);
                });
                successModal.classList.add('show');
            }

            modalCloseBtn.addEventListener('click', () => successModal.classList.remove('show'));
            successModal.addEventListener('click', (e) => {
                if (e.target === successModal) successModal.classList.remove('show');
            });

            function formatBytes(bytes, decimals = 2) {
                if (bytes === 0) return '0 Bytes';
                const k = 1024;
                const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
                const i = Math.floor(Math.log(bytes) / Math.log(k));
                return parseFloat((bytes / Math.pow(k, i)).toFixed(decimals < 0 ? 0 : decimals)) + ' ' + sizes[i];
            }
        });
    </script>
</body>
</html