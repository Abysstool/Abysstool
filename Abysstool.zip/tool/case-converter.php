 <?php
// Set current year for footer
$currentYear = date("2025");
// Determine current page for navigation
$current_page = basename($_SERVER['PHP_SELF'], '.php');

// --- Tool-specific information ---
$toolData = [
    'id' => 'case-converter',
    'name' => 'Text Case Converter',
    'description' => 'Easily convert text between different letter cases: uppercase, lowercase, sentence case, and more. All processing is done securely in your browser.',
    'icon' => 'fas fa-font', // Choose a relevant Font Awesome icon
    'logoUrl' => 'https://placehold.co/40x40/800000/FFFFFF?text=Aa' // Optional: create a simple logo
];
?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php include 'head.php'; ?> 
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- SEO Meta Tags for your new tool -->
    <meta name="description" content="<?php echo $toolData['description']; ?>">
    <meta name="keywords" content="text converter, case converter, uppercase, lowercase, sentence case, privacy tool, secure text tool">
    <meta name="author" content="AbyssTools Team">
    <meta property="og:title" content="<?php echo $toolData['name']; ?> - AbyssTool">
    <meta property="og:description" content="<?php echo $toolData['description']; ?>">
    
    <title><?php echo $toolData['name']; ?> - AbyssTool</title>
    
    <!-- Links to your main CSS and fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../style.css">

    <!-- === START: TOOL-SPECIFIC CSS (INCLUDING FAQ STYLES) === -->
    <style>
        /* Styles for the converter interface */
        .case-converter-textarea {
            width: 100%;
            min-height: 200px;
            padding: 1rem;
            background: rgba(0, 0, 0, 0.3);
            border: 1px solid var(--primary);
            color: var(--text);
            border-radius: var(--border-radius-sm);
            font-size: 1rem;
            margin-bottom: 1.5rem;
            resize: vertical;
        }

        .case-converter-buttons {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 1rem;
        }

        .case-converter-buttons .btn.small {
            width: 100%;
            margin: 0;
            padding: 0.7rem;
            text-align: center;
        }

        /* --- STYLES COPIED FROM IMAGE-TO-TEXT FOR FAQS --- */
        .faq-section {
            margin: 3.5rem 0;
        }
        
        .faq-container {
            max-width: 800px;
            margin: 0 auto;
        }
        
        .faq-item {
            background: var(--card-bg);
            border: 1px solid var(--card-border);
            border-radius: var(--border-radius-md);
            margin-bottom: 1rem;
            overflow: hidden;
            transition: var(--transition);
        }
        
        .faq-item:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
            border-color: var(--primary);
        }
        
        .faq-question {
            padding: 1.2rem;
            margin: 0;
            cursor: pointer;
            color: var(--primary-light);
            font-weight: 600;
            position: relative;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .faq-question::after {
            content: "+";
            font-size: 1.5rem;
            transition: var(--transition);
        }
        
        .faq-item.active .faq-question::after {
            content: "−";
        }
        
        .faq-answer {
            padding: 0 1.2rem;
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease-out, padding 0.3s ease;
            background: rgba(0, 0, 0, 0.1);
        }
        
        .faq-item.active .faq-answer {
            padding: 1.2rem;
            max-height: 500px; /* Adjust if you have very long answers */
        }
        
        .faq-answer p {
            line-height: 1.7;
            margin-bottom: 1rem;
        }
    </style>
    <!-- === END: TOOL-SPECIFIC CSS === -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "WebApplication",
      "@id": "https://abysstool.42web.io/tool/case-converter",
      "url": "https://abysstool.42web.io/tool/case-converter",
      "name": "Text Case Converter - Abysstool",
      "description": "Easily convert text between different letter cases: uppercase, lowercase, sentence case, and more. All processing is done securely in your browser.",
      "applicationCategory": "UtilitiesApplication",
      "operatingSystem": "Any",
      "offers": {
        "@type": "Offer",
        "price": "0"
      },
      "isPartOf": {
        "@id": "https://abysstool.42web.io/#website"
      }
    },
    {
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://abysstool.42web.io/" },
        { "@type": "ListItem", "position": 2, "name": "All Tools", "item": "https://abysstool.42web.io/tools" },
        { "@type": "ListItem", "position": 3, "name": "Text Case Converter", "item": "https://abysstool.42web.io/tool/case-converter" }
      ]
    },
    {
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "Is the text I enter into this tool secure?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Absolutely. This is the core principle of AbyssTools. The conversion logic runs entirely on your computer (client-side). Your text is never sent to our servers or any third party. You can verify this by using your browser's developer tools to monitor network activity – you will see none when you use the converter."
          }
        },
        {
          "@type": "Question",
          "name": "What is the difference between \"Sentence case\" and \"Capitalized Case\"?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Sentence case: Capitalizes only the first letter of each sentence. It identifies sentences by looking for periods, question marks, and exclamation points. Capitalized Case (or Title Case): Capitalizes the first letter of every word. This is commonly used for headlines and titles."
          }
        },
        {
          "@type": "Question",
          "name": "Is there a character limit for the text I can convert?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "There is no hard-coded limit. The tool can handle very large blocks of text, limited only by the memory and processing power of your own device and browser. For typical use cases, you will not encounter any limits."
          }
        },
        {
          "@type": "Question",
          "name": "Does this tool support languages other than English?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, the basic UPPERCASE and lowercase functions will work with most languages and character sets. The \"Sentence case\" and \"Capitalized Case\" functions are optimized for languages that use a similar sentence and word structure to English but should still work reasonably well for many others."
          }
        }
      ]
    }
  ]
}
</script>
</head>
<body>
    <?php include '../header.php'; ?>

    <!-- Main Content for the Tool -->
    <main class="main-content tool-page">
        <div class="content">
            <!-- 1. Tool Hero Section -->
            <section class="tool-hero animate-on-scroll">
                <div class="tool-hero-content">
                    <div class="tool-icon-large">
                        <img src="<?php echo $toolData['logoUrl']; ?>" alt="<?php echo $toolData['name']; ?> Logo" class="tool-logo-large">
                        <i class="<?php echo $toolData['icon']; ?>"></i>
                    </div>
                    <h1><?php echo $toolData['name']; ?></h1>
                    <p class="tool-description-large"><?php echo $toolData['description']; ?></p>
                </div>
            </section>
            
            <!-- 2. Tool Interface Section -->
            <section class="tool-interface animate-on-scroll">
                <div class="tool-container">
                    <textarea id="text-input" class="case-converter-textarea" placeholder="Enter or paste your text here..."></textarea>
                    
                    <div class="case-converter-buttons">
                        <button id="btn-upper" class="btn small">UPPERCASE</button>
                        <button id="btn-lower" class="btn small">lowercase</button>
                        <button id="btn-sentence" class="btn small">Sentence case</button>
                        <button id="btn-capitalized" class="btn small">Capitalized Case</button>
                        <button id="btn-clear" class="btn small primary">Clear Text</button>
                    </div>
                </div>
            </section>
            
            <!-- === START: NEW CONTENT SECTION === -->
            <section class="seo-content animate-on-scroll">
                <h2>About the Privacy-Focused Text Case Converter</h2>
                <p>This tool allows you to instantly modify text capitalization without your data ever leaving your device. It's an essential utility for writers, editors, developers, and students who need to quickly format text while maintaining complete privacy and security.</p>
                
                <h3>Why Your Privacy Matters</h3>
                <p>When you paste text into most online tools, it gets sent to a server where it can be stored, analyzed, or even sold. This text could contain confidential business information, personal notes, or drafts of sensitive documents. Our tool eliminates this risk entirely.</p>
                
                <ul>
                    <li><strong>Zero Data Collection:</strong> We do not see, save, or store anything you type or paste.</li>
                    <li><strong>Client-Side Processing:</strong> All conversions happen in your browser using JavaScript.</li>
                    <li><strong>No Tracking:</strong> We don't use cookies or scripts to monitor your activity.</li>
                    <li><strong>Works Offline:</strong> Once the page is loaded, you can disconnect from the internet and the tool will still function perfectly.</li>
                </ul>
            </section>
            <!-- === END: NEW CONTENT SECTION === -->

            <!-- === START: NEW FAQ SECTION === -->
            <section class="faq-section animate-on-scroll">
                <h2 class="section-title">Frequently Asked Questions</h2>
                
                <div class="faq-container">
                    <div class="faq-item">
                        <h3 class="faq-question">Is the text I enter into this tool secure?</h3>
                        <div class="faq-answer">
                            <p><strong>Absolutely.</strong> This is the core principle of AbyssTools. The conversion logic runs entirely on your computer (client-side). Your text is never sent to our servers or any third party. You can verify this by using your browser's developer tools to monitor network activity – you will see none when you use the converter.</p>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <h3 class="faq-question">What is the difference between "Sentence case" and "Capitalized Case"?</h3>
                        <div class="faq-answer">
                            <p><strong>Sentence case:</strong> Capitalizes only the first letter of each sentence. It identifies sentences by looking for periods, question marks, and exclamation points.</p>
                            <p><strong>Capitalized Case (or Title Case):</strong> Capitalizes the first letter of every word. This is commonly used for headlines and titles.</p>
                        </div>
                    </div>

                    <div class="faq-item">
                        <h3 class="faq-question">Is there a character limit for the text I can convert?</h3>
                        <div class="faq-answer">
                            <p>There is no hard-coded limit. The tool can handle very large blocks of text, limited only by the memory and processing power of your own device and browser. For typical use cases, you will not encounter any limits.</p>
                        </div>
                    </div>

                    <div class="faq-item">
                        <h3 class="faq-question">Does this tool support languages other than English?</h3>
                        <div class="faq-answer">
                            <p>Yes, the basic UPPERCASE and lowercase functions will work with most languages and character sets. The "Sentence case" and "Capitalized Case" functions are optimized for languages that use a similar sentence and word structure to English but should still work reasonably well for many others.</p>
                        </div>
                    </div>
                </div>
            </section>
            <!-- === END: NEW FAQ SECTION === -->
        </div>
    </main>
    
    <?php include '../footer.php'; ?>
    
    <!-- Your site's live background and main JS file -->
    <canvas id="horror-canvas"></canvas>
    <div id="scan-lines"></div>
    <div id="glitch-overlay"></div>
    <script src="../style.js"></script>

    <!-- === START: TOOL-SPECIFIC JAVASCRIPT (WITH FAQ LOGIC) === -->
    <script>
    document.addEventListener('DOMContentLoaded', () => {
        // --- Logic for the Case Converter Tool ---
        const textArea = document.getElementById('text-input');

        document.getElementById('btn-upper').addEventListener('click', () => {
            textArea.value = textArea.value.toUpperCase();
        });

        document.getElementById('btn-lower').addEventListener('click', () => {
            textArea.value = textArea.value.toLowerCase();
        });

        document.getElementById('btn-sentence').addEventListener('click', () => {
            let text = textArea.value.toLowerCase();
            // Capitalize the first letter of each sentence.
            textArea.value = text.replace(/(^\s*\w|[.!?]\s*\w)/g, (c) => c.toUpperCase());
        });

        document.getElementById('btn-capitalized').addEventListener('click', () => {
            let text = textArea.value.toLowerCase();
            // Capitalize the first letter of each word.
            textArea.value = text.replace(/\b\w/g, (c) => c.toUpperCase());
        });

        document.getElementById('btn-clear').addEventListener('click', () => {
            textArea.value = '';
        });

        // --- Logic for the FAQ Accordion (copied from image-to-text) ---
        const faqQuestions = document.querySelectorAll('.faq-question');
        faqQuestions.forEach(question => {
            question.addEventListener('click', () => {
                const faqItem = question.closest('.faq-item');
                faqItem.classList.toggle('active');
            });
        });
    });
    </script>
    <!-- === END: TOOL-SPECIFIC JAVASCRIPT === -->

</body>
</html