 <?php
// Set current year for footer
$currentYear = date("2025");
// Determine current page for navigation
$current_page = basename($_SERVER['PHP_SELF'], '.php');

// --- Tool-specific information ---
$toolData = [
    'id' => 'age-calculator',
    'name' => 'Age Calculator',
    'description' => 'Calculate age from date of birth or find the exact time duration between two dates. Accurate, secure, and works worldwide without collecting any data.',
    'icon' => 'fas fa-calendar-alt',
    'logoUrl' => 'https://placehold.co/40x40/800000/FFFFFF?text=CALC'
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include 'head.php'; ?> 

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- SEO Meta Tags -->
    <meta name="description" content="<?php echo $toolData['description']; ?>">
    <meta name="keywords" content="age calculator, date difference, time between dates, birthday calculator, privacy tool, secure date calculator, chronological age">
    <meta name="author" content="AbyssTools Team">
    <meta property="og:title" content="<?php echo $toolData['name']; ?> - AbyssTool">
    <meta property="og:description" content="<?php echo $toolData['description']; ?>">
    
    <title><?php echo $toolData['name']; ?> - AbyssTool</title>
    
    <!-- Main CSS and Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../style.css">

    <!-- === START: TOOL-SPECIFIC CSS === -->
    <style>
        .tool-tabs { display: flex; gap: 0.5rem; margin-bottom: 1.5rem; border-bottom: 2px solid var(--card-border); }
        .tab-btn { padding: 0.8rem 1.2rem; cursor: pointer; background: transparent; border: none; color: var(--text-secondary); font-size: 1rem; font-weight: 600; transition: var(--transition); border-bottom: 3px solid transparent; position: relative; top: 2px; }
        .tab-btn.active { color: var(--primary-light); border-bottom-color: var(--primary); }
        .tab-content { display: none; }
        .tab-content.active { display: block; animation: fadeIn 0.5s; }
        .date-inputs { display: grid; grid-template-columns: 1fr; gap: 1.5rem; margin-bottom: 1.5rem; }
        @media (min-width: 768px) { .date-inputs { grid-template-columns: 1fr 1fr; } }
        .input-group { display: flex; flex-direction: column; gap: 0.5rem; }
        .input-group label { font-weight: 500; color: var(--text-secondary); font-size: 0.95rem; }
        .input-group input[type="date"] { padding: 0.7rem; background: rgba(0, 0, 0, 0.3); border: 1px solid var(--primary); color: var(--text); border-radius: var(--border-radius-sm); font-family: inherit; font-size: 1rem; }
        .input-group input[type="date"]::-webkit-calendar-picker-indicator { filter: invert(0.5) sepia(1) saturate(5) hue-rotate(335deg); cursor: pointer; }
        #calculate-btn { width: 100%; max-width: 300px; margin: 1rem auto; }
        .results-container { margin-top: 2rem; display: none; }
        .primary-result { background: rgba(128, 0, 0, 0.15); padding: 1.7rem; border-radius: var(--border-radius-md); margin-bottom: 1.5rem; border-left: 3px solid var(--primary); text-align: center; }
        .primary-result h3 { color: var(--primary-light); margin-bottom: 0.5rem; font-size: 1.3rem; text-transform: uppercase; letter-spacing: 1px; }
        .primary-result p { font-size: 2.2rem; font-weight: 700; color: var(--text); margin: 0; padding: 0; border: none; }
        .primary-result p span { color: var(--primary); }
        .summary-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 1rem; }
        .summary-card { background: var(--card-bg); border: 1px solid var(--card-border); padding: 1.2rem; border-radius: var(--border-radius-md); text-align: center; transition: var(--transition); }
        .summary-card:hover { transform: translateY(-3px); border-color: var(--primary); box-shadow: var(--shadow-md); }
        .summary-card .value { font-size: 1.5rem; font-weight: 600; color: var(--primary-light); }
        .summary-card .label { font-size: 0.9rem; color: var(--text-secondary); margin-top: 0.3rem; }
        .error-message { color: var(--primary-light); text-align: center; margin-top: 1rem; background: rgba(128, 0, 0, 0.2); padding: 0.8rem; border-radius: var(--border-radius-sm); border-left: 3px solid var(--primary); }
        
        /* FAQ Styles copied from image-to-text tool for consistency */
        .tool-page .faq-item { background: var(--card-bg); border: 1px solid var(--card-border); border-radius: var(--border-radius-md); margin-bottom: 1rem; overflow: hidden; transition: var(--transition); }
        .tool-page .faq-item:hover { transform: translateY(-2px); box-shadow: var(--shadow-md); border-color: var(--primary); }
        .tool-page .faq-question { padding: 1.2rem; margin: 0; cursor: pointer; color: var(--primary-light); font-weight: 600; position: relative; display: flex; align-items: center; justify-content: space-between; }
        .tool-page .faq-question::after { content: "+"; font-size: 1.5rem; transition: var(--transition); }
        .tool-page .faq-item.active .faq-question::after { content: "−"; transform: rotate(180deg); }
        .tool-page .faq-answer { padding: 0 1.2rem; max-height: 0; overflow: hidden; transition: max-height 0.4s ease-out, padding 0.4s ease; background: rgba(0, 0, 0, 0.1); }
        .tool-page .faq-item.active .faq-answer { padding: 1.2rem; max-height: 500px; }
        .tool-page .faq-answer p, .tool-page .faq-answer li { line-height: 1.7; margin-bottom: 1rem; }
    </style>
    <!-- === END: TOOL-SPECIFIC CSS === -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "WebApplication",
      "@id": "https://abysstool.42web.io/tool/age-calculator",
      "url": "https://abysstool.42web.io/tool/age-calculator",
      "name": "Age Calculator - Abysstool",
      "description": "Calculate age from date of birth or find the exact time duration between two dates. Accurate, secure, and works worldwide without collecting any data.",
      "applicationCategory": "UtilitiesApplication",
      "operatingSystem": "Any",
      "offers": {
        "@type": "Offer",
        "price": "0"
      },
      "isPartOf": {
        "@id": "https://abysstool.42web.io/#website"
      }
    },
    {
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://abysstool.42web.io/" },
        { "@type": "ListItem", "position": 2, "name": "All Tools", "item": "https://abysstool.42web.io/tools" },
        { "@type": "ListItem", "position": 3, "name": "Age Calculator", "item": "https://abysstool.42web.io/tool/age-calculator" }
      ]
    },
    {
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "How does the calculator determine my age?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "It calculates your chronological age by finding the precise time passed from your date of birth to a target date. The calculation accurately accounts for the varying days in each month and includes leap years to give you a result in years, months, and days."
          }
        },
        {
          "@type": "Question",
          "name": "Is my date of birth information saved or tracked?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Absolutely not. This is a core principle of AbyssTools. All calculations are performed locally in your browser. Your data is never sent to our servers, logged, or stored. Once you close the browser tab, the information is gone forever."
          }
        },
        {
          "@type": "Question",
          "name": "Can I calculate the difference between future dates?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes. The 'Date Difference' calculator works for past, present, and future dates. You can use it to calculate the time remaining until a future event, such as a vacation, a deadline, or a retirement date."
          }
        },
        {
          "@type": "Question",
          "name": "Does the calculation account for leap years?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, the algorithm correctly identifies and includes leap years (when February has 29 days) within the specified date range. This ensures the total number of days and the overall duration are calculated with complete accuracy."
          }
        },
        {
          "@type": "Question",
          "name": "How can I use this for project management?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Use the 'Date Difference' tab. Set the 'Start Date' to your project's kick-off and the 'End Date' to the deadline. The tool will instantly tell you the total number of days or weeks you have, which is crucial for resource planning and setting milestones."
          }
        }
      ]
    }
  ]
}
</script>
</head>
<body>
    <?php include '../header.php'; ?>

    <main class="main-content tool-page">
        <div class="content">
            <section class="tool-hero animate-on-scroll">
                <div class="tool-hero-content">
                    <div class="tool-icon-large">
                        <img src="<?php echo $toolData['logoUrl']; ?>" alt="<?php echo $toolData['name']; ?> Logo" class="tool-logo-large">
                        <i class="<?php echo $toolData['icon']; ?>"></i>
                    </div>
                    <h1><?php echo $toolData['name']; ?></h1>
                    <p class="tool-description-large"><?php echo $toolData['description']; ?></p>
                </div>
            </section>
            
            <section class="tool-interface animate-on-scroll">
                <div class="tool-container">
                    <div class="tool-tabs">
                        <button class="tab-btn active" data-tab="age">Age Calculator</button>
                        <button class="tab-btn" data-tab="difference">Date Difference</button>
                    </div>
                    <div id="tab-age" class="tab-content active">
                        <div class="date-inputs"><div class="input-group"><label for="dob">Your Date of Birth</label><input type="date" id="dob"></div><div class="input-group"><label for="age_at_date">Age at the Date of</label><input type="date" id="age_at_date"></div></div>
                    </div>
                    <div id="tab-difference" class="tab-content">
                        <div class="date-inputs"><div class="input-group"><label for="start_date">Start Date</label><input type="date" id="start_date"></div><div class="input-group"><label for="end_date">End Date</label><input type="date" id="end_date"></div></div>
                    </div>
                    <button id="calculate-btn" class="btn">Calculate</button>
                    <p id="error-message" class="error-message" style="display:none;"></p>
                    <div id="results-container" class="results-container"><div id="primary-result-container" class="primary-result"></div><h3 class="section-title" style="margin-top:2.5rem; font-size: 1.5rem;">Summary in Different Units</h3><div class="summary-grid"><div class="summary-card"><p id="summary-months" class="value">0</p><p class="label">Total Months</p></div><div class="summary-card"><p id="summary-weeks" class="value">0</p><p class="label">Total Weeks</p></div><div class="summary-card"><p id="summary-days" class="value">0</p><p class="label">Total Days</p></div><div class="summary-card"><p id="summary-hours" class="value">0</p><p class="label">Total Hours</p></div></div></div>
                </div>
            </section>
            
            <section class="seo-content animate-on-scroll">
                <h2>Precise Time Calculations, Absolute Privacy</h2>
                <p>Whether you're determining your exact chronological age for official documents or calculating the duration of a project, precision matters. Our Age & Date Difference Calculator provides accurate results down to the day, accounting for complex factors like leap years. This tool is indispensable for personal, academic, and professional use worldwide.</p>
                <h3>Why Use a Privacy-Focused Date Calculator?</h3>
                <p>Dates, especially a date of birth, are personally identifiable information (PII). When you use a standard online calculator, you risk that data being logged, stored, and potentially used without your consent. AbyssTools eliminates this risk entirely:</p>
                <ul><li><strong>Zero Data Transmission:</strong> All calculations are performed directly in your browser. Your date of birth or any other date you enter is never sent to our servers.</li><li><strong>Instantaneous Results:</strong> Without the need for server communication, your results are calculated and displayed instantly.</li><li><strong>Offline Functionality:</strong> Once the page is loaded, the tool can be used without an internet connection, guaranteeing that your data remains on your device.</li><li><strong>Universal Application:</strong> The tool is useful for a variety of tasks, from planning events and tracking project timelines to genealogical research and historical analysis.</li></ul>
            </section>

            <section class="faq-section animate-on-scroll">
                <h2 class="section-title">Frequently Asked Questions</h2>
                <div class="faq-container">
                    <div class="faq-item"><h3 class="faq-question">How does the calculator determine my age?</h3><div class="faq-answer"><p>It calculates your chronological age by finding the precise time passed from your date of birth to a target date. The calculation accurately accounts for the varying days in each month and includes leap years to give you a result in years, months, and days.</p></div></div>
                    <div class="faq-item"><h3 class="faq-question">Is my date of birth information saved or tracked?</h3><div class="faq-answer"><p>Absolutely not. This is a core principle of AbyssTools. All calculations are performed locally in your browser. Your data is never sent to our servers, logged, or stored. Once you close the browser tab, the information is gone forever.</p></div></div>
                    <div class="faq-item"><h3 class="faq-question">Can I calculate the difference between future dates?</h3><div class="faq-answer"><p>Yes. The "Date Difference" calculator works for past, present, and future dates. You can use it to calculate the time remaining until a future event, such as a vacation, a deadline, or a retirement date.</p></div></div>
                    <div class="faq-item"><h3 class="faq-question">Does the calculation account for leap years?</h3><div class="faq-answer"><p>Yes, the algorithm correctly identifies and includes leap years (when February has 29 days) within the specified date range. This ensures the total number of days and the overall duration are calculated with complete accuracy.</p></div></div>
                    <div class="faq-item"><h3 class="faq-question">What's the difference between the "Age" and "Date Difference" tabs?</h3><div class="faq-answer"><p>The "Age Calculator" is optimized for finding a person's age, presenting it in the familiar "Years, Months, Days" format. The "Date Difference" calculator is a more general tool for finding the exact time duration between any two arbitrary dates.</p></div></div>
                    <div class="faq-item"><h3 class="faq-question">Why does the summary show different totals for months, weeks, and days?</h3><div class="faq-answer"><p>The main result (e.g., "25 years, 3 months, 10 days") gives a human-readable breakdown. The summary cards show the *total* duration converted into a single unit. For example, "Total Days" is the absolute number of days between the two dates, not just the "10 days" from the main result.</p></div></div>
                    <div class="faq-item"><h3 class="faq-question">How can I use this for project management?</h3><div class="faq-answer"><p>Use the "Date Difference" tab. Set the "Start Date" to your project's kick-off and the "End Date" to the deadline. The tool will instantly tell you the total number of days or weeks you have, which is crucial for resource planning and setting milestones.</p></div></div>
                </div>
            </section>
        </div>
    </main>
    
    <?php include '../footer.php'; ?>
    
    <canvas id="horror-canvas"></canvas>
    <div id="scan-lines"></div>
    <div id="glitch-overlay"></div>
    <script src="../style.js"></script>

    <!-- === START: TOOL-SPECIFIC JAVASCRIPT === -->
    <script>
    document.addEventListener('DOMContentLoaded', () => {
        // Tab switching logic
        const tabs = document.querySelectorAll('.tab-btn');
        const tabContents = document.querySelectorAll('.tab-content');
        let activeTab = 'age';
        tabs.forEach(tab => {
            tab.addEventListener('click', () => {
                activeTab = tab.dataset.tab;
                tabs.forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                tabContents.forEach(c => c.classList.remove('active'));
                document.getElementById(`tab-${activeTab}`).classList.add('active');
                document.getElementById('results-container').style.display = 'none';
                document.getElementById('error-message').style.display = 'none';
            });
        });

        // Set default dates to today
        document.getElementById('age_at_date').valueAsDate = new Date();
        document.getElementById('end_date').valueAsDate = new Date();

        // FAQ Accordion Logic
        const faqItems = document.querySelectorAll('.faq-item');
        faqItems.forEach(item => {
            const question = item.querySelector('.faq-question');
            question.addEventListener('click', () => {
                // Optional: Close other open FAQs
                // faqItems.forEach(otherItem => {
                //     if (otherItem !== item) otherItem.classList.remove('active');
                // });
                item.classList.toggle('active');
            });
        });

        // Calculation Logic
        const calculateBtn = document.getElementById('calculate-btn');
        calculateBtn.addEventListener('click', () => {
            const resultsContainer = document.getElementById('results-container');
            const errorEl = document.getElementById('error-message');
            resultsContainer.style.display = 'none';
            errorEl.style.display = 'none';

            let startDate, endDate;

            if (activeTab === 'age') {
                const dob = document.getElementById('dob').value;
                const ageAtDate = document.getElementById('age_at_date').value;
                if (!dob || !ageAtDate) { showError("Please fill in both dates."); return; }
                startDate = new Date(dob);
                endDate = new Date(ageAtDate);
            } else {
                const start = document.getElementById('start_date').value;
                const end = document.getElementById('end_date').value;
                if (!start || !end) { showError("Please fill in both dates."); return; }
                startDate = new Date(start);
                endDate = new Date(end);
            }
            
            // Adjust for timezone offset to prevent off-by-one day errors
            startDate = new Date(startDate.getTime() + startDate.getTimezoneOffset() * 60000);
            endDate = new Date(endDate.getTime() + endDate.getTimezoneOffset() * 60000);

            if (startDate > endDate) { showError("The start date cannot be later than the end date."); return; }

            calculateAndDisplay(startDate, endDate);
        });

        function showError(message) {
            const errorEl = document.getElementById('error-message');
            errorEl.textContent = message;
            errorEl.style.display = 'block';
        }

        function calculateAndDisplay(start, end) {
            let years = end.getFullYear() - start.getFullYear();
            let months = end.getMonth() - start.getMonth();
            let days = end.getDate() - start.getDate();

            if (days < 0) {
                months--;
                const lastDayOfPrevMonth = new Date(end.getFullYear(), end.getMonth(), 0).getDate();
                days += lastDayOfPrevMonth;
            }
            if (months < 0) {
                years--;
                months += 12;
            }
            
            const title = activeTab === 'age' ? 'Your Precise Age Is' : 'Time Difference';
            document.getElementById('primary-result-container').innerHTML = `<h3>${title}</h3><p><span>${years}</span> years, <span>${months}</span> months, <span>${days}</span> days</p>`;
            
            const diffTime = Math.abs(end - start);
            const totalDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
            
            document.getElementById('summary-months').textContent = (years * 12 + months).toLocaleString();
            document.getElementById('summary-weeks').textContent = Math.floor(totalDays / 7).toLocaleString();
            document.getElementById('summary-days').textContent = totalDays.toLocaleString();
            document.getElementById('summary-hours').textContent = (totalDays * 24).toLocaleString();

            document.getElementById('results-container').style.display = 'block';
        }
    });
    </script>
    <!-- === END: TOOL-SPECIFIC JAVASCRIPT === -->
</body>
</html