 <?php
// Set current year for footer
$currentYear = date("2025");
// Determine current page for navigation
$current_page = basename($_SERVER['PHP_SELF'], '.php');

// --- Tool-specific information ---
$toolData = [
    'id' => 'emi-calculator',
    'name' => 'EMI Calculator',
    'description' => 'Calculate your Equated Monthly Instalment (EMI) for home, car, or personal loans. Secure, private, and works offline with detailed PDF reports.',
    'icon' => 'fas fa-wallet',
    'logoUrl' => 'https://placehold.co/40x40/800000/FFFFFF?text=₹'
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include 'head.php'; ?> 

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo $toolData['description']; ?>">
    <meta name="keywords" content="emi calculator, loan emi calculator, home loan emi, car loan emi, personal loan emi, amortization schedule, privacy tool, secure emi tool">
    <meta name="author" content="AbyssTool Team">
    <meta property="og:title" content="<?php echo $toolData['name']; ?> - AbyssTool">
    <meta property="og:description" content="<?php echo $toolData['description']; ?>">
    <title><?php echo $toolData['name']; ?> - AbyssTool</title>
    
    <!-- Main CSS and Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../style.css">

    <!-- === START: EMI CALCULATOR SPECIFIC CSS === -->
    <style>
        .calculator-layout { display: grid; grid-template-columns: 350px 1fr; gap: 2rem; }
        .calculator-sidebar { display: flex; flex-direction: column; gap: 1.5rem; }
        .calculator-form, .results-summary, .optional-details-form { background: var(--card-bg); border: 1px solid var(--card-border); padding: 1.5rem; border-radius: var(--border-radius-lg); }
        .form-grid { display: flex; flex-direction: column; gap: 1rem; }
        .input-group { display: flex; flex-direction: column; gap: 0.5rem; }
        .input-group label { font-weight: 500; color: var(--text-secondary); font-size: 0.9rem; }
        .input-group input, .input-group select, .input-group textarea { padding: 0.7rem; background: rgba(0, 0, 0, 0.4); border: 1px solid var(--primary); color: var(--text); border-radius: var(--border-radius-sm); font-size: 1rem; width: 100%; font-family: inherit; }
        .input-group input:focus, .input-group select:focus, .input-group textarea:focus { outline: none; border-color: var(--primary-light); box-shadow: 0 0 0 3px rgba(255, 0, 0, 0.2); }
        .calculate-button-container { margin-top: 1.5rem; }
        .result-item { padding: 1rem; border-bottom: 1px solid var(--card-border); }
        .result-item:last-child { border-bottom: none; padding-bottom: 0; }
        .result-item:first-child { padding-top: 0; }
        .result-item h3 { font-size: 0.9rem; color: var(--text-secondary); margin-bottom: 0.5rem; font-weight: 500; }
        .result-item p { font-size: 1.5rem; font-weight: 700; color: var(--primary-light); margin: 0; padding: 0; border: none; }
        .cost-breakdown { display: flex; gap: 1rem; margin-top: 0.5rem; }
        .cost-breakdown span { font-size: 0.85rem; }
        .cost-breakdown .principal { color: #23d5ab; } .cost-breakdown .interest { color: #23a6d5; }
        .calculator-main { background: var(--card-bg); border: 1px solid rgba(255, 255, 255, 0.1); border-radius: var(--border-radius-lg); overflow: hidden; }
        .tabs-nav { display: flex; background-color: rgba(0,0,0,0.3); border-bottom: 1px solid var(--card-border); }
        .tab-link { padding: 1rem 1.5rem; cursor: pointer; border: none; background: none; color: var(--text-secondary); font-weight: 600; transition: var(--transition); border-bottom: 3px solid transparent; }
        .tab-link.active { color: var(--primary-light); border-bottom-color: var(--primary); }
        .tab-content { padding: 1.5rem; display: none; }
        .tab-content.active { display: block; }
        #amortization-table-wrapper { max-height: 500px; overflow-y: auto; }
        #amortization-table { width: 100%; border-collapse: collapse; }
        #amortization-table th, #amortization-table td { padding: 0.8rem; text-align: left; border-bottom: 1px solid var(--card-border); }
        #amortization-table th { color: var(--primary-light); position: sticky; top: 0; background: var(--card-bg); }
        .faq-item { background: rgba(25, 0, 0, 0.6); border: 1px solid var(--card-border); border-radius: var(--border-radius-md); margin-bottom: 1rem; overflow: hidden; transition: var(--transition); }
        .faq-item:hover { transform: translateY(-2px); box-shadow: var(--shadow-md); border-color: var(--primary); }
        .faq-question { padding: 1.2rem; margin: 0; cursor: pointer; color: var(--primary-light); font-weight: 600; position: relative; display: flex; align-items: center; justify-content: space-between; }
        .faq-question::after { content: "+"; font-size: 1.5rem; transition: var(--transition); }
        .faq-item.active .faq-question::after { content: "−"; }
        .faq-answer { padding: 0 1.2rem; max-height: 0; overflow: hidden; transition: max-height 0.3s ease-out, padding 0.3s ease; background: rgba(0, 0, 0, 0.2); }
        .faq-item.active .faq-answer { padding: 1.2rem; max-height: 500px; }
        .faq-answer p, .faq-answer ul { color: var(--text-secondary); }
        .error-box { background: rgba(128, 0, 0, 0.5); border: 1px solid var(--primary-dark); color: var(--text); padding: 1rem; border-radius: var(--border-radius-sm); margin-top: 1rem; font-weight: 500; }
        @media (max-width: 1023px) { .calculator-layout { grid-template-columns: 1fr; } }
    </style>
    <!-- === END: EMI CALCULATOR SPECIFIC CSS === -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "WebApplication",
      "@id": "https://abysstool.42web.io/tool/loan-calculator",
      "url": "https://abysstool.42web.io/tool/loan-calculator",
      "name": "Loan Calculator - Abysstool",
      "description": "Calculate your monthly loan payments for home, car, or personal loans. See a full amortization schedule and download a private, detailed report.",
      "applicationCategory": "FinanceApplication",
      "operatingSystem": "Any",
      "offers": {
        "@type": "Offer",
        "price": "0"
      },
      "isPartOf": {
        "@id": "https://abysstool.42web.io/#website"
      }
    },
    {
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://abysstool.42web.io/" },
        { "@type": "ListItem", "position": 2, "name": "All Tools", "item": "https://abysstool.42web.io/tools" },
        { "@type": "ListItem", "position": 3, "name": "Loan Calculator", "item": "https://abysstool.42web.io/tool/loan-calculator" }
      ]
    },
    {
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "What is an EMI?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "EMI stands for Equated Monthly Instalment. It is the fixed payment amount that a borrower pays to a lender every month. Each EMI payment includes a portion of the principal loan amount and the interest accrued."
          }
        },
        {
          "@type": "Question",
          "name": "What is an amortization schedule?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "It is a detailed table that shows the breakdown of each monthly payment into its principal and interest components. It also shows the remaining loan balance after each payment, giving you a clear picture of how your loan is being paid off over time."
          }
        },
        {
          "@type": "Question",
          "name": "How can I reduce my monthly loan payment?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "You can reduce your monthly payment by either opting for a longer loan tenure (which increases the total interest paid) or by securing a lower interest rate from your lender. Making a larger down payment also reduces the principal amount, thereby lowering the payment."
          }
        },
        {
          "@type": "Question",
          "name": "Does this calculator include processing fees or other charges?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "No, this is a pure loan payment calculator. It does not factor in one-time charges like processing fees, prepayment penalties, or other administrative costs that a lender might apply. You should always check with your lender for a complete cost breakdown."
          }
        },
        {
          "@type": "Question",
          "name": "Why does the interest part of my payment decrease over time?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "In the beginning of the loan, the outstanding principal is high, so the interest component is larger. As you pay off the loan, the principal balance reduces, which in turn reduces the amount of interest charged in each subsequent payment. This means a larger portion of your payment goes towards the principal as time goes on."
          }
        }
      ]
    }
  ]
}
</script>
</head>
<body>
    <?php include '../header.php'; ?>

    <main class="main-content tool-page">
        <div class="content">
            <section class="tool-hero animate-on-scroll"><div class="tool-hero-content"><div class="tool-icon-large"><img src="<?php echo $toolData['logoUrl']; ?>" alt="<?php echo $toolData['name']; ?> Logo" class="tool-logo-large"><i class="<?php echo $toolData['icon']; ?>"></i></div><h1><?php echo $toolData['name']; ?></h1><p class="tool-description-large"><?php echo $toolData['description']; ?></p></div></section>
            
            <section class="tool-interface animate-on-scroll">
                <div class="calculator-layout">
                    <aside class="calculator-sidebar">
                        <div class="calculator-form">
                            <h2 class="section-title" style="margin-bottom: 1.5rem;">Loan Details</h2>
                            <div class="form-grid">
                                <div class="input-group"><label for="currency">Currency</label><select id="currency"><option value="₹">INR (₹)</option><option value="$">USD ($)</option> <option value="€">EUR (€)</option> <option value="£">GBP (£)</option> <option value="¥">JPY (¥)</option> <option value="CA$">CAD (CA$)</option> <option value="AU$">AUD (AU$)</option></select></div>
                                <div class="input-group"><label for="loanAmount">Loan Amount</label><input type="number" id="loanAmount" placeholder="1000000" min="1"></div>
                                <div class="input-group"><label for="interestRate">Annual Interest Rate (%)</label><input type="number" id="interestRate" placeholder="8.5" step="0.01" min="0"></div>
                                <div class="input-group"><label for="loanTerm">Loan Term (Years)</label><input type="number" id="loanTerm" placeholder="20" min="1"></div>
                                <div class="input-group"><label for="startDate">Loan Start Date (Optional)</label><input type="date" id="startDate"></div>
                            </div>
                            <div class="calculate-button-container"><button id="calculateBtn" class="btn">Calculate EMI</button></div>
                            <div id="error-message-box" class="error-box" style="display: none;"></div>
                        </div>

                        <div id="results-section" class="results-summary" style="display: none;">
                            <h2 class="section-title" style="margin-bottom: 1.5rem;">EMI Summary</h2>
                            <div class="result-item"><h3>Monthly EMI</h3><p id="paymentAmount">--</p></div>
                            <div class="result-item"><h3>Total Interest Paid</h3><p id="totalInterest">--</p></div>
                            <div class="result-item"><h3>Total Payment (Principal + Interest)</h3><p id="totalPayment">--</p><div class="cost-breakdown"><span class="principal" id="principalPercent"></span> <span class="interest" id="interestPercent"></span></div></div>
                            <div class="result-item"><h3>Payoff Details</h3><p id="totalPayments" style="font-size:1.2rem; margin-bottom: 0.2rem;"></p><p id="payoffDate" style="font-size:1.2rem;"></p></div>
                            <div style="text-align:center; padding-top: 1.5rem;"><button id="downloadPdfBtn" class="btn">Download Full Report</button></div>
                        </div>
                        
                        <div id="optional-details-section" class="optional-details-form" style="display: none;">
                             <h2 class="section-title" style="margin-bottom: 1.5rem;">Optional Details for PDF</h2>
                             <div class="form-grid">
                                <div class="input-group"><label for="borrowerName">Borrower's Name</label><input type="text" id="borrowerName" placeholder="John Doe"></div>
                                <div class="input-group"><label for="lenderName">Lender's Name</label><input type="text" id="lenderName" placeholder="Example Bank"></div>
                                <div class="input-group"><label for="borrowerAddress">Borrower's Address</label><textarea id="borrowerAddress" rows="3" placeholder="123 Privacy Lane..."></textarea></div>
                             </div>
                        </div>
                    </aside>
                    
                    <main id="calculator-main-content" class="calculator-main" style="display: none;">
                        <nav class="tabs-nav"><button class="tab-link active" data-tab="chart">Payment Breakdown Chart</button><button class="tab-link" data-tab="schedule">Amortization Schedule</button></nav>
                        <div id="tab-chart" class="tab-content active"><canvas id="paymentChart"></canvas></div>
                        <div id="tab-schedule" class="tab-content"><div id="amortization-table-wrapper"><table id="amortization-table"><thead><tr><th>#</th><th>Date</th><th>Principal</th><th>Interest</th><th>EMI</th><th>Balance</th></tr></thead><tbody id="amortization-body"></tbody></table></div></div>
                    </main>
                </div>
            </section>
            
            <section class="seo-content animate-on-scroll">
                <h2>Plan Your Finances with a Secure EMI Calculator</h2>
                <p>An Equated Monthly Instalment (EMI) is the fixed payment amount made by a borrower to a lender at a specified date each month. EMIs are used to pay off both interest and principal each month so that over a specified number of years, the loan is paid off in full. Understanding your EMI is the first step toward smart financial planning for major purchases like a home, car, or for a personal loan.</p>
                <h3>Why Your Privacy Matters When Calculating EMIs</h3>
                <p>When you use an online EMI calculator, you are inputting sensitive financial data—your loan amount, your financial capacity, and your future plans. Many websites collect this information for lead generation, selling your data to banks and lenders. AbyssTools is different:</p>
                <ul>
                    <li><strong>Zero Data Collection:</strong> Your financial details are processed in your browser and are never sent to our servers. We don't know who you are or what you calculate.</li>
                    <li><strong>No Tracking or Ads:</strong> We don't use tracking cookies or profile you for advertising. Your financial planning stays completely private.</li>
                    <li><strong>Offline Functionality:</strong> Once the page is loaded, you can use the calculator offline, ensuring a 100% secure environment for your calculations.</li>
                </ul>
            </section>
            
            <section class="faq-section animate-on-scroll">
                <h2 class="section-title">Frequently Asked Questions</h2>
                <div class="faq-container">
                    <div class="faq-item"><h3 class="faq-question">What is an EMI?</h3><div class="faq-answer"><p>EMI stands for Equated Monthly Instalment. It is a fixed payment amount that a borrower pays to a lender every month on a specific date. Each EMI payment includes a portion of the principal loan amount and the interest accrued on the loan.</p></div></div>
                    <div class="faq-item"><h3 class="faq-question">How is the EMI calculated?</h3><div class="faq-answer"><p>The EMI is calculated using a standard formula: P x R x (1+R)^N / [(1+R)^N-1], where P is the principal loan amount, R is the monthly interest rate (annual rate divided by 12), and N is the number of monthly installments (loan term in years multiplied by 12).</p></div></div>
                    <div class="faq-item"><h3 class="faq-question">What is an amortization schedule?</h3><div class="faq-answer"><p>It is a detailed table that shows the breakdown of each EMI payment into its principal and interest components. It also shows the remaining loan balance after each payment, giving you a clear picture of how your loan is being paid off over time.</p></div></div>
                    <div class="faq-item"><h3 class="faq-question">How can I reduce my EMI?</h3><div class="faq-answer"><p>You can reduce your EMI by either opting for a longer loan tenure (which increases the total interest paid) or by securing a lower interest rate from your lender. Making a larger down payment also reduces the principal amount, thereby lowering the EMI.</p></div></div>
                    <div class="faq-item"><h3 class="faq-question">Does this calculator include processing fees or other charges?</h3><div class="faq-answer"><p>No, this is a pure EMI calculator. It does not factor in one-time charges like processing fees, prepayment penalties, or other administrative costs that a lender might apply. You should always check with your lender for a complete cost breakdown.</p></div></div>
                    <div class="faq-item"><h3 class="faq-question">Why does the interest component of the EMI decrease over time?</h3><div class="faq-answer"><p>In the beginning of the loan, the outstanding principal is high, so the interest component is larger. As you pay off the loan, the principal balance reduces, which in turn reduces the amount of interest charged in each subsequent EMI. This means a larger portion of your EMI goes towards paying off the principal as time goes on.</p></div></div>
                </div>
            </section>
        </div>
    </main>
    
    <?php include '../footer.php'; ?>
    
    <canvas id="horror-canvas"></canvas><div id="scan-lines"></div><div id="glitch-overlay"></div>
    <script src="../style.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.23/jspdf.plugin.autotable.min.js"></script>
    <!-- === START: EMI CALCULATOR SPECIFIC JAVASCRIPT === -->
    <script>
    document.addEventListener('DOMContentLoaded', () => {
        const calculateBtn = document.getElementById('calculateBtn');
        const resultsSection = document.getElementById('results-section');
        const optionalSection = document.getElementById('optional-details-section');
        const mainContent = document.getElementById('calculator-main-content');
        const tabLinks = document.querySelectorAll('.tab-link');
        const downloadPdfBtn = document.getElementById('downloadPdfBtn');
        const errorBox = document.getElementById('error-message-box');
        let paymentChart; let lastCalculationData = {};

        calculateBtn.addEventListener('click', calculateAndDisplay);
        tabLinks.forEach(link => link.addEventListener('click', () => switchTab(link.dataset.tab)));
        downloadPdfBtn.addEventListener('click', downloadPDF);
        document.querySelectorAll('.faq-question').forEach(q => q.closest('.faq-item').addEventListener('click', (e) => {
            e.currentTarget.classList.toggle('active');
        }));

        function calculateAndDisplay() {
            const inputs = getInputs();
            if (!inputs) return;
            hideError();
            const calculation = calculateStandardLoan(inputs);
            lastCalculationData = { inputs, calculation };
            displaySummary(calculation.summary, inputs, calculation.schedule);
            updatePaymentChart(calculation.chartData);
            populateAmortizationTable(calculation.schedule, inputs);
            showResults();
        }

        function getInputs() {
            const loanAmount = parseFloat(document.getElementById('loanAmount').value);
            const annualInterestRate = parseFloat(document.getElementById('interestRate').value);
            const years = parseFloat(document.getElementById('loanTerm').value);
            if (isNaN(loanAmount) || loanAmount <= 0 || isNaN(annualInterestRate) || annualInterestRate < 0 || isNaN(years) || years <= 0) {
                showError("Please fill in all fields with valid positive numbers."); return null;
            }
            const startDateEl = document.getElementById('startDate');
            let startDate = startDateEl.value ? new Date(startDateEl.value + 'T00:00:00') : new Date();
            return {
                currency: document.getElementById('currency').value,
                principal: loanAmount, annualInterestRate, years, startDate
            };
        }
        
        function calculateStandardLoan(inputs) {
            const periodicRate = (inputs.annualInterestRate / 100) / 12; // EMI is always monthly
            const numPayments = inputs.years * 12;
            const payment = periodicRate === 0 ? inputs.principal / numPayments : inputs.principal * (periodicRate * Math.pow(1 + periodicRate, numPayments)) / (Math.pow(1 + periodicRate, numPayments) - 1);
            const totalPayment = payment * numPayments;
            const totalInterest = totalPayment - inputs.principal;
            
            let balance = inputs.principal;
            const schedule = [];
            const chartData = { labels: [], principalPaid: [], interestPaid: [] };
            let currentDate = new Date(inputs.startDate);

            for (let i = 1; i <= numPayments; i++) {
                const interestPayment = balance * periodicRate;
                const principalPayment = payment - interestPayment;
                balance -= principalPayment;
                if (i > 1) currentDate.setMonth(currentDate.getMonth() + 1); // Increment date for next payments
                schedule.push({ pNum: i, date: new Date(currentDate), principal: principalPayment, interest: interestPayment, total: payment, balance: balance < 0 ? 0 : balance });
                chartData.labels.push(i);
                chartData.principalPaid.push(principalPayment);
                chartData.interestPaid.push(interestPayment);
            }
            return { summary: { payment, totalInterest, totalPayment, numPayments }, schedule, chartData };
        }

        function displaySummary({ payment, totalInterest, totalPayment, numPayments }, { currency, principal }, schedule) {
            const format = (num) => `${currency}${num.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`;
            const principalPercent = (principal / totalPayment * 100).toFixed(1);
            const interestPercent = (totalInterest / totalPayment * 100).toFixed(1);
            const payoffDate = schedule.length > 0 ? schedule[schedule.length - 1].date : new Date();
            document.getElementById('paymentAmount').textContent = format(payment);
            document.getElementById('totalInterest').textContent = format(totalInterest);
            document.getElementById('totalPayment').textContent = format(totalPayment);
            document.getElementById('principalPercent').textContent = `Principal: ${principalPercent}%`;
            document.getElementById('interestPercent').textContent = `Interest: ${interestPercent}%`;
            document.getElementById('totalPayments').textContent = `${numPayments} Payments`;
            document.getElementById('payoffDate').textContent = `Final Payoff: ${payoffDate.toLocaleDateString(undefined, { month: 'long', year: 'numeric' })}`;
        }

        function populateAmortizationTable(schedule, { currency }) {
            const tbody = document.getElementById('amortization-body');
            tbody.innerHTML = '';
            const format = (num) => `${currency}${num.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`;
            schedule.forEach(p => tbody.insertAdjacentHTML('beforeend', `<tr><td>${p.pNum}</td><td>${p.date.toLocaleDateString()}</td><td>${format(p.principal)}</td><td>${format(p.interest)}</td><td>${format(p.total)}</td><td>${format(p.balance)}</td></tr>`));
        }
        
        function updatePaymentChart({ labels, principalPaid, interestPaid }) {
            if (paymentChart) paymentChart.destroy();
            paymentChart = new Chart(document.getElementById('paymentChart').getContext('2d'), {
                type: 'bar',
                data: { labels, datasets: [{ label: 'Principal', data: principalPaid, backgroundColor: '#23d5ab' }, { label: 'Interest', data: interestPaid, backgroundColor: '#23a6d5' }] },
                options: { responsive: true, maintainAspectRatio: false, scales: { x: { stacked: true, ticks: { color: 'var(--text-secondary)' }, grid: { color: 'var(--card-border)' } }, y: { stacked: true, ticks: { color: 'var(--text-secondary)' }, grid: { color: 'var(--card-border)' } } }, plugins: { legend: { labels: { color: 'var(--text)' } } } }
            });
        }
        
        function switchTab(tabId) { document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active')); document.querySelectorAll('.tab-link').forEach(l => l.classList.remove('active')); document.getElementById(`tab-${tabId}`).classList.add('active'); document.querySelector(`.tab-link[data-tab="${tabId}"]`).classList.add('active'); }
        function showResults() { resultsSection.style.display = 'block'; mainContent.style.display = 'block'; optionalSection.style.display = 'block'; }
        function hideResults() { resultsSection.style.display = 'none'; mainContent.style.display = 'none'; optionalSection.style.display = 'none'; hideError(); }
        function showError(msg) { errorBox.textContent = msg; errorBox.style.display = 'block'; }
        function hideError() { errorBox.style.display = 'none'; }
        
        function downloadPDF() {
            if (!lastCalculationData.inputs) { showError("Please perform a calculation first."); return; }
            const { jsPDF } = window.jspdf; const doc = new jsPDF();
            const { inputs, calculation } = lastCalculationData; const { summary, schedule } = calculation;
            const format = (num) => `${inputs.currency}${num.toFixed(2)}`;
            const optionalDetails = { name: document.getElementById('borrowerName').value, address: document.getElementById('borrowerAddress').value, lender: document.getElementById('lenderName').value };
            
            const addHeaderFooter = () => {
                const pageCount = doc.internal.getNumberOfPages();
                for (let i = 1; i <= pageCount; i++) {
                    doc.setPage(i);
                    doc.setFillColor(128, 0, 0); doc.rect(0, 0, 210, 25, 'F');
                    doc.setFontSize(20); doc.setFont("helvetica", "bold"); doc.setTextColor(255, 255, 255);
                    doc.text("AbyssTool EMI Report", 105, 15, { align: "center" });
                    doc.setFontSize(10); doc.setTextColor(150, 150, 150);
                    doc.text(`Page ${i} of ${pageCount} | Generated securely by abysstools.com`, 105, 287, { align: "center" });
                }
            };
            
            let startY = 35;
            if (optionalDetails.name || optionalDetails.lender || optionalDetails.address) {
                doc.setFontSize(12); doc.setFont("helvetica", "bold"); doc.setTextColor(0, 0, 0); doc.text("Report For:", 14, startY);
                let detailsText = `${optionalDetails.name || 'N/A'}\n${optionalDetails.address || 'N/A'}\nLender: ${optionalDetails.lender || 'N/A'}`;
                doc.setFontSize(11); doc.setFont("helvetica", "normal"); doc.text(detailsText, 14, startY + 7);
                startY += 25;
            }

            doc.autoTable({
                startY: startY, head: [['Loan Parameter', 'Value']],
                body: [
                    ['Loan Amount', format(inputs.principal)], ['Annual Interest Rate', `${inputs.annualInterestRate}%`], ['Loan Term', `${inputs.years} Years`],
                    ['Monthly EMI', format(summary.payment)], ['Total Interest', format(summary.totalInterest)],
                    ['Total Payment', format(summary.totalPayment)], ['Final Payoff Date', schedule[schedule.length - 1].date.toLocaleDateString()],
                ],
                theme: 'grid', headStyles: { fillColor: [40, 40, 40] },
            });
            doc.addPage();
            doc.setFontSize(16); doc.setFont("helvetica", "bold"); doc.text("Payment Breakdown Chart", 105, 40, { align: "center" });
            const chartImage = paymentChart.canvas.toDataURL('image/png', 1.0);
            doc.addImage(chartImage, 'PNG', 15, 50, 180, 90);
            const tableRows = schedule.map(p => [p.pNum, p.date.toLocaleDateString(), format(p.principal), format(p.interest), format(p.total), format(p.balance)]);
            doc.autoTable({
                head: [["#", "Date", "Principal", "Interest", "EMI", "Balance"]],
                body: tableRows, startY: 150,
                headStyles: { fillColor: [128, 0, 0] }, theme: 'striped',
                margin: { top: 30 }
            });
            addHeaderFooter();
            doc.save('EMI-Report-AbyssTool.pdf');
        }
    });
    </script>
    <!-- === END: EMI CALCULATOR SPECIFIC JAVASCRIPT === -->
</body>
</html