 // Hamburger menu toggle
const hamburger = document.getElementById('hamburger');
const navbar = document.getElementById('navbar');

// Close mobile menu when clicking on a nav link
document.addEventListener('click', function(e) {
    // Handle dropdown clicks on mobile
    if (e.target.closest('.dropdown') && window.innerWidth <= 768) {
        e.preventDefault();
        const dropdown = e.target.closest('.dropdown');
        dropdown.classList.toggle('active');
    }
    
    // Close mobile menu when clicking on a nav link
    if (e.target.classList.contains('nav-link') || e.target.closest('.dropdown-item')) {
        hamburger.classList.remove('open');
        navbar.classList.remove('active');
    }
});

// View All Tools button - FIXED TO NAVIGATE TO tools.php
document.addEventListener('DOMContentLoaded', function() {
    const viewAllBtn = document.getElementById('view-all-tools');
    if (viewAllBtn) {
        viewAllBtn.addEventListener('click', function(e) {
            e.preventDefault();
            window.location.href = 'tools.php';  // Fixed: Navigates to tools.php
        });
    }
    
    // Initialize dropdowns
    document.querySelectorAll('.dropdown').forEach(dropdown => {
        const menu = dropdown.querySelector('.dropdown-menu');
        const link = dropdown.querySelector('.nav-link');
        
        // Desktop hover
        dropdown.addEventListener('mouseenter', () => {
            if (window.innerWidth > 768) {
                menu.style.opacity = '1';
                menu.style.pointerEvents = 'all';
                menu.style.transform = 'translateX(-50%) translateY(5px)';
            }
        });
        
        dropdown.addEventListener('mouseleave', () => {
            if (window.innerWidth > 768) {
                menu.style.opacity = '0';
                menu.style.pointerEvents = 'none';
                menu.style.transform = 'translateX(-50%) translateY(0)';
            }
        });
        
        // Mobile click
        link.addEventListener('click', (e) => {
            if (window.innerWidth <= 768 && !e.target.closest('.dropdown-item')) {
                e.preventDefault();
                dropdown.classList.toggle('active');
            }
        });
    });
    
    // Close dropdowns when clicking outside
    document.addEventListener('click', (e) => {
        if (window.innerWidth > 768) return;
        
        document.querySelectorAll('.dropdown').forEach(dropdown => {
            if (!dropdown.contains(e.target)) {
                dropdown.classList.remove('active');
            }
        });
    });
});

// SINGLE SOURCE OF TRUTH FOR ALL TOOLS - UPDATED WITH INDIVIDUAL TOOL PAGE LINKS
let toolsData = [

{
    id: 'image-compressor',
    name: 'Image Compressor',
    description: 'Compress JPG, PNG, and WEBP images with incredible speed. Our tool is privacy-focused and works entirely in your browser.',
    icon: 'fas fa-compress-arrows-alt',
    link: '/tool/image-compressor.php',
        logoUrl: 'https://placehold.co/40x40/800000/FFFFFF?text=IC'
},


    {
        id: 'age-calculator',
        name: 'Age Calculator',
        description: 'Calculate your exact age or the time between two dates. Secure, private, and works worldwide with support for leap years.',
        icon: 'fas fa-calendar-alt',
        link: '/tool/age-calculator.php',
            logoUrl: 'https://placehold.co/40x40/800000/FFFFFF?text=AGE'
    },
    {
        id: 'case-converter',
        name: 'Text Case Converter',
        description: 'Easily convert text between different letter cases: uppercase, lowercase, sentence case, and more. All processing is done securely in your browser.',
        icon: 'fas fa-font',
        link: '/tool/case-converter.php',
            logoUrl: 'https://placehold.co/40x40/800000/FFFFFF?text=CASE'
    },
{
    id: 'emi-calculator',
    name: 'EMI Calculator',
    description: 'Calculate your Equated Monthly Instalment (EMI) for home, car, or personal loans. Secure, private, and works offline with detailed PDF reports.',
    icon: 'fas fa-wallet', // A relevant icon for EMIs
    link: 'tool/emi-calculator.php',
    // Rupee sign for EMI context
    logoUrl: 'https://placehold.co/40x40/800000/FFFFFF?text=EMI'
},
{
    id: 'loan-calculator',
    name: 'Loan Calculator',
    description: 'Analyze standard (EMI) or interest-only loans. View interactive charts and detailed amortization schedules. Secure, private, and works offline.',
    icon: 'fas fa-chart-pie', // A more descriptive icon
    link: '/tool/loan-calculator.php',
        logoUrl: 'https://placehold.co/40x40/800000/FFFFFF?text=Loan'
},

    
{
    id: 'bmi-calculator',
    name: 'BMI Calculator',
    description: 'A comprehensive and private health metrics tool. Calculate your BMI, ideal weight, BMR, and daily calorie needs securely in your browser.',
    icon: 'fas fa-calculator',
    link: '/tool/bmi-calculator.php',
        logoUrl: 'https://placehold.co/40x40/800000/FFFFFF?text=BMI'
}
];

// Render tools on homepage (featured tools)
function renderHomeTools() {
    const toolsGrid = document.getElementById('tools-grid');
    if (!toolsGrid) return;
    
    toolsGrid.innerHTML = '';
    
    // Calculate how many tools fit in 5 rows
    const rowHeight = 330; // tool-card height + margin
    const viewportHeight = window.innerHeight;
    const maxRows = 5;
    const toolsPerRow = Math.floor(toolsGrid.offsetWidth / 300); // 280px card + 20px gap
    const maxTools = maxRows * toolsPerRow;
    
    // Only show up to maxTools
    const toolsToShow = toolsData.slice(0, maxTools);
    
    toolsToShow.forEach(tool => {
        const toolCard = document.createElement('div');
        toolCard.className = 'tool-card animate-on-scroll';
        toolCard.id = `tool-${tool.id}`;
        toolCard.innerHTML = `
            <div class="tool-icon">
                ${tool.logoUrl ? `<img src="${tool.logoUrl}" alt="${tool.name} Logo" class="tool-logo">` : ''}
                <i class="${tool.icon}"></i>
            </div>
            <h3 class="tool-title">${tool.name}</h3>
            <p class="tool-description">${tool.description}</p>
            <a href="${tool.link}" class="tool-btn">Use Tool <i class="fas fa-arrow-right" style="margin-left: 5px;"></i></a>
        `;
        toolsGrid.appendChild(toolCard);
    });
    
    // Initialize animation on scroll for new elements
    initScrollAnimation();
}

// Render ALL tools on tools page
function renderAllTools() {
    const allToolsGrid = document.getElementById('all-tools-grid');
    if (!allToolsGrid) return;
    
    allToolsGrid.innerHTML = '';
    
    toolsData.forEach(tool => {
        const toolCard = document.createElement('div');
        toolCard.className = 'tool-card animate-on-scroll';
        toolCard.id = `tool-${tool.id}`;
        toolCard.innerHTML = `
            <div class="tool-icon">
                ${tool.logoUrl ? `<img src="${tool.logoUrl}" alt="${tool.name} Logo" class="tool-logo">` : ''}
                <i class="${tool.icon}"></i>
            </div>
            <h3 class="tool-title">${tool.name}</h3>
            <p class="tool-description">${tool.description}</p>
            <a href="${tool.link}" class="tool-btn">Use Tool <i class="fas fa-arrow-right" style="margin-left: 5px;"></i></a>
        `;
        allToolsGrid.appendChild(toolCard);
    });
    
    // Initialize animation on scroll for new elements
    initScrollAnimation();
}

// Enhanced search functionality - ONLY SEARCHES BY TOOL NAME
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('tool-search');
    if (!searchInput) return;
    
    const searchResultsContainer = document.getElementById('search-results');
    const searchResultsList = document.getElementById('search-results-list');
    
    // Function to highlight matching text
    function highlightMatch(text, searchTerm) {
        if (!searchTerm) return text;
        
        const regex = new RegExp(`(${searchTerm})`, 'gi');
        return text.replace(regex, '<span class="search-highlight">$1</span>');
    }
    
    // Function to perform search - ONLY MATCHES TOOL NAMES
    function performSearch() {
        const searchTerm = searchInput.value.toLowerCase().trim();
        
        if (searchTerm === '') {
            searchResultsContainer.classList.remove('active');
            searchResultsList.innerHTML = '';
            return;
        }
        
        // Filter tools based on search term - ONLY SEARCHES NAME, NOT DESCRIPTION
        const filteredTools = toolsData.filter(tool => {
            return tool.name.toLowerCase().includes(searchTerm);
        });
        
        // Display results
        if (filteredTools.length > 0) {
            searchResultsList.innerHTML = '';
            
            filteredTools.forEach(tool => {
                const resultItem = document.createElement('div');
                resultItem.className = 'search-result-item';
                resultItem.innerHTML = `
                    <div class="tool-card-mini">
                        <div class="tool-info">
                            <h3 class="tool-title-mini">${highlightMatch(tool.name, searchTerm)}</h3>
                        </div>
                        <a href="${tool.link}" class="tool-btn-mini">Use Tool <i class="fas fa-arrow-right"></i></a>
                    </div>
                `;
                
                resultItem.addEventListener('click', function() {
                    // Add the tool to the main grid
                    const toolsGrid = document.getElementById('tools-grid');
                    if (!toolsGrid) return;
                    
                    toolsGrid.innerHTML = '';
                    
                    const toolCard = document.createElement('div');
                    toolCard.className = 'tool-card animate-on-scroll';
                    toolCard.id = `tool-${tool.id}`;
                    toolCard.innerHTML = `
                        <div class="tool-icon">
                            ${tool.logoUrl ? `<img src="${tool.logoUrl}" alt="${tool.name} Logo" class="tool-logo">` : ''}
                            <i class="${tool.icon}"></i>
                        </div>
                        <h3 class="tool-title">${tool.name}</h3>
                        <p class="tool-description">${tool.description}</p>
                        <a href="${tool.link}" class="tool-btn">Use Tool <i class="fas fa-arrow-right" style="margin-left: 5px;"></i></a>
                    `;
                    toolsGrid.appendChild(toolCard);
                    
                    // Initialize animation for new element
                    initScrollAnimation();
                    
                    // Clear search
                    searchInput.value = '';
                    searchResultsContainer.classList.remove('active');
                    searchResultsList.innerHTML = '';
                });
                
                searchResultsList.appendChild(resultItem);
            });
            
            searchResultsContainer.classList.add('active');
        } else {
            searchResultsList.innerHTML = `
                <div class="no-results-message">
                    <i class="fas fa-search"></i> No tools found matching "${searchTerm}"
                </div>
            `;
            searchResultsContainer.classList.add('active');
        }
    }
    
    // Set up search functionality
    searchInput.addEventListener('input', performSearch);
    
    // Close search results when clicking outside
    document.addEventListener('click', function(e) {
        if (!searchInput.contains(e.target) && !searchResultsContainer.contains(e.target)) {
            searchResultsContainer.classList.remove('active');
        }
    });
});

// Initialize scroll animation
function initScrollAnimation() {
    const animateElements = document.querySelectorAll('.animate-on-scroll');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
            }
        });
    }, {
        threshold: 0.1
    });
    
    animateElements.forEach(element => {
        observer.observe(element);
    });
}

// Initialize header scroll effect
function initHeaderScroll() {
    const header = document.querySelector('header');
    
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });
}

    

// Initialize the site when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize scroll animation
    initScrollAnimation();
    
    // Initialize header scroll effect
    initHeaderScroll();
    
    
    
    // Render appropriate tools based on which page we're on
    if (document.getElementById('tools-grid')) {
        renderHomeTools();
    } else if (document.getElementById('all-tools-grid')) {
        renderAllTools();
    }
    
    // Hamburger menu toggle
    if (hamburger) {
        hamburger.addEventListener('click', () => {
            hamburger.classList.toggle('open');
            navbar.classList.toggle('active');
        });
    }
    
    // Initialize canvas background
    const canvas = document.getElementById('horror-canvas');
    if (canvas) {
        const ctx = canvas.getContext('2d');
        
        // Set canvas size
        function resizeCanvas() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        }
        resizeCanvas();
        window.addEventListener('resize', resizeCanvas);
        
        // Blood particles
        const bloodParticles = [];
        const particleCount = 50;
        
        class BloodParticle {
            constructor() {
                this.reset();
            }
            
            reset() {
                this.x = Math.random() * canvas.width;
                this.y = Math.random() * canvas.height;
                this.size = Math.random() * 3 + 1;
                this.speedX = Math.random() * 2 - 1;
                this.speedY = Math.random() * 1 + 1;
                this.color = `rgba(180, ${Math.random() * 50}, ${Math.random() * 20}, ${Math.random() * 0.8 + 0.2})`;
                this.rotation = Math.random() * Math.PI * 2;
                this.rotationSpeed = Math.random() * 0.05 - 0.025;
            }
            
            update() {
                this.x += this.speedX;
                this.y += this.speedY;
                this.rotation += this.rotationSpeed;
                
                // Reset if off screen
                if (this.y > canvas.height + 10 || this.x < -10 || this.x > canvas.width + 10) {
                    this.reset();
                    this.y = -10; // Start from above
                }
            }
            
            draw() {
                ctx.save();
                ctx.translate(this.x, this.y);
                ctx.rotate(this.rotation);
                
                ctx.fillStyle = this.color;
                ctx.beginPath();
                ctx.moveTo(0, 0);
                ctx.bezierCurveTo(
                    this.size, -this.size, 
                    -this.size, -this.size, 
                    0, this.size * 2
                );
                ctx.fill();
                
                ctx.restore();
            }
        }
        
        // Floating eyes
        const eyes = [];
        const eyeCount = 8;
        
        class Eye {
            constructor() {
                this.x = Math.random() * canvas.width;
                this.y = Math.random() * canvas.height;
                this.size = Math.random() * 20 + 15;
                this.pupilSize = this.size * 0.4;
                this.speed = Math.random() * 0.5 + 0.1;
                this.angle = Math.random() * Math.PI * 2;
                this.orbitRadius = Math.random() * 100 + 50;
                this.orbitCenterX = this.x;
                this.orbitCenterY = this.y;
                this.blinkTimer = 0;
                this.blinkDuration = 0;
            }
            
            update() {
                // Orbital movement
                this.angle += this.speed / 100;
                this.x = this.orbitCenterX + Math.cos(this.angle) * this.orbitRadius;
                this.y = this.orbitCenterY + Math.sin(this.angle) * this.orbitRadius;
                
                // Keep within bounds
                if (this.x < this.size) {
                    this.orbitCenterX += 2;
                } else if (this.x > canvas.width - this.size) {
                    this.orbitCenterX -= 2;
                }
                
                if (this.y < this.size) {
                    this.orbitCenterY += 2;
                } else if (this.y > canvas.height - this.size) {
                    this.orbitCenterY -= 2;
                }
                
                // Blinking
                this.blinkTimer++;
                if (this.blinkTimer > 300 + Math.random() * 600) {
                    this.blinkDuration = 10;
                    this.blinkTimer = 0;
                }
                this.blinkDuration--;
            }
            
            draw() {
                // Eye white
                ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
                ctx.beginPath();
                ctx.ellipse(this.x, this.y, this.size, this.size * 0.7, 0, 0, Math.PI * 2);
                ctx.fill();
                
                // Pupil (follow mouse)
                let mouseX = canvas.width / 2;
                let mouseY = canvas.height / 2;
                
                window.addEventListener('mousemove', (e) => {
                    mouseX = e.clientX;
                    mouseY = e.clientY;
                });
                
                const dx = mouseX - this.x;
                const dy = mouseY - this.y;
                const distance = Math.sqrt(dx * dx + dy * dy);
                const maxDist = 100;
                
                let pupilX = this.x;
                let pupilY = this.y;
                
                if (distance < maxDist) {
                    const angle = Math.atan2(dy, dx);
                    const followDist = (maxDist - distance) / maxDist * 5;
                    pupilX = this.x + Math.cos(angle) * followDist;
                    pupilY = this.y + Math.sin(angle) * followDist;
                }
                
                // Blink effect
                if (this.blinkDuration > 0) {
                    ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
                    ctx.beginPath();
                    ctx.ellipse(this.x, this.y, this.size, 2, 0, 0, Math.PI * 2);
                    ctx.fill();
                    return;
                }
                
                // Pupil
                ctx.fillStyle = '#800000';
                ctx.beginPath();
                ctx.ellipse(pupilX, pupilY, this.pupilSize, this.pupilSize * 0.7, 0, 0, Math.PI * 2);
                ctx.fill();
                
                // Highlight
                ctx.fillStyle = 'rgba(255, 0, 0, 0.8)';
                ctx.beginPath();
                ctx.ellipse(
                    pupilX - this.pupilSize * 0.2, 
                    pupilY - this.pupilSize * 0.2, 
                    this.pupilSize * 0.4, 
                    this.pupilSize * 0.3, 0, 0, Math.PI * 2
                );
                ctx.fill();
            }
        }
        
        // Floating text (like whispers)
        const whispers = [
            "They're watching...",
            "Can't escape...",
            "Behind you...",
            "No light here...",
            "Forever trapped...",
            "Join us...",
            "So cold...",
            "Never wake up...",
            "Your data is safe...",
            "Privacy is power...",
            "Zero tracking...",
            "No data collected..."
        ];
        
        const floatingTexts = [];
        const textCount = 5;
        
        class FloatingText {
            constructor() {
                this.reset();
            }
            
            reset() {
                this.text = whispers[Math.floor(Math.random() * whispers.length)];
                this.x = Math.random() * canvas.width;
                this.y = Math.random() * canvas.height;
                this.opacity = Math.random() * 0.4 + 0.2;
                this.size = Math.random() * 20 + 14;
                this.speedX = Math.random() * 2 - 1;
                this.speedY = Math.random() * 2 - 1;
                this.fadeIn = Math.random() > 0.5;
                this.duration = Math.random() * 200 + 100;
                this.timer = 0;
            }
            
            update() {
                this.x += this.speedX;
                this.y += this.speedY;
                this.timer++;
                
                if (this.timer > this.duration) {
                    this.reset();
                }
                
                // Fade in/out effect
                if (this.fadeIn) {
                    this.opacity += 0.005;
                    if (this.opacity >= 0.6) {
                        this.fadeIn = false;
                    }
                } else {
                    this.opacity -= 0.005;
                    if (this.opacity <= 0.1) {
                        this.fadeIn = true;
                    }
                }
                
                // Wrap around screen
                if (this.x < -100) this.x = canvas.width + 100;
                if (this.x > canvas.width + 100) this.x = -100;
                if (this.y < -50) this.y = canvas.height + 50;
                if (this.y > canvas.height + 50) this.y = -50;
            }
            
            draw() {
                ctx.font = `bold ${this.size}px 'Raleway'`;
                ctx.fillStyle = `rgba(255, ${Math.floor(Math.random() * 100)}, ${Math.floor(Math.random() * 50)}, ${this.opacity})`;
                ctx.fillText(this.text, this.x, this.y);
                
                // Add slight distortion
                ctx.save();
                ctx.globalCompositeOperation = 'color-dodge';
                ctx.fillText(this.text, this.x + 2, this.y + 2);
                ctx.restore();
            }
        }
        
        // Initialize horror elements
        function initHorror() {
            // Blood particles
            for (let i = 0; i < particleCount; i++) {
                const particle = new BloodParticle();
                // Start particles at the top
                particle.y = -i * 10;
                bloodParticles.push(particle);
            }
            
            // Eyes
            for (let i = 0; i < eyeCount; i++) {
                eyes.push(new Eye());
            }
            
            // Floating whispers
            for (let i = 0; i < textCount; i++) {
                floatingTexts.push(new FloatingText());
            }
        }
        
        // Blood drip effect
        function createBloodDrip() {
            if (Math.random() < 0.03) {  // 3% chance each frame
                const drip = document.createElement('div');
                drip.className = 'blood-drip';
                drip.style.left = Math.random() * window.innerWidth + 'px';
                drip.style.animationDuration = (Math.random() * 5 + 3) + 's';
                document.body.appendChild(drip);
                
                // Remove element after animation completes
                setTimeout(() => {
                    if (drip.parentElement) {
                        document.body.removeChild(drip);
                    }
                }, 8000);
            }
        }
        
        // Glitch effect
        function createGlitch() {
            if (Math.random() < 0.02) {  // 2% chance
                const overlay = document.getElementById('glitch-overlay');
                overlay.style.opacity = '0.4';
                
                setTimeout(() => {
                    overlay.style.opacity = '0.1';
                }, 200);
            }
        }
        
        // Animation loop
        function animate() {
            // Semi-transparent clear for trail effect
            ctx.fillStyle = 'rgba(0, 0, 0, 0.1)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            
            // Update and draw blood particles
            for (let i = 0; i < bloodParticles.length; i++) {
                bloodParticles[i].update();
                bloodParticles[i].draw();
            }
            
            // Update and draw eyes
            for (let i = 0; i < eyes.length; i++) {
                eyes[i].update();
                eyes[i].draw();
            }
            
            // Update and draw floating text
            for (let i = 0; i < floatingTexts.length; i++) {
                floatingTexts[i].update();
                floatingTexts[i].draw();
            }
            
            // Periodic effects
            createBloodDrip();
            createGlitch();
            
            requestAnimationFrame(animate);
        }
        
        initHorror();
        animate();
    }
})