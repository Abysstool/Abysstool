 <?php
// Set current year for footer
$currentYear = date("2025");
// Determine current page for navigation
$current_page = basename($_SERVER['PHP_SELF'], '.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include 'head.php'; ?> 

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="AbyssTools - Terms and Conditions for using our privacy-focused tools with zero data collection.">
    <meta name="keywords" content="privacy tools, terms and conditions, no data collection, secure tools, privacy policy, terms of service, abysstools">
    <meta name="author" content="AbyssTools Team">
    <meta name="robots" content="index, follow">
    <meta property="og:type" content="website">
    <meta property="og:title" content="Terms and Conditions - AbyssTools | Privacy Tools">
    <meta property="og:description" content="Read the terms and conditions for using AbyssTools privacy-focused utilities. We respect your privacy with zero data collection.">
    <meta property="og:url" content="https://abysstool.42web.io/terms">
    <meta property="og:image" content="https://abysstool.42web.io/terms-cover.png">
    <meta property="og:site_name" content="AbyssTools">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Terms and Conditions - AbyssTools | Privacy Tools">
    <meta name="twitter:description" content="Read the terms and conditions for using AbyssTools privacy-focused utilities. We respect your privacy with zero data collection.">
    <meta name="twitter:image" content="https://abysstool.42web.io/terms-cover.png">
    <title>AbyssTool - Terms</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
<style>
/* Terms Page Specific Styles */
.terms-page .hero {
    margin-bottom: 3rem;
    padding: 3rem;
    background: var(--card-bg);
    border-radius: var(--border-radius-lg);
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    box-shadow: var(--shadow-md);
    border: 1px solid var(--card-border);
    position: relative;
    overflow: hidden;
}

.terms-page .hero::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(120deg, rgba(255, 0, 0, 0.03) 0%, transparent 100%);
    z-index: 0;
}

.terms-page .hero:hover {
    transform: translateY(-3px);
    box-shadow: var(--shadow-lg);
}

.terms-page .terms-section {
    margin: 3.5rem 0;
}

.terms-page .terms-container {
    max-width: 800px;
    margin: 0 auto;
    background: var(--card-bg);
    border-radius: var(--border-radius-lg);
    padding: 2.5rem;
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    border: 1px solid var(--card-border);
    box-shadow: var(--shadow-md);
}

.terms-page p {
    line-height: 1.75;
    margin-bottom: 1.5rem;
    color: var(--text-secondary);
}

.terms-page h2 {
    font-size: 1.9rem;
    margin: 2rem 0 1.2rem;
    color: var(--primary-light);
    position: relative;
    padding-left: 1.2rem;
}

.terms-page h2::before {
    content: '';
    position: absolute;
    left: 0;
    top: 50%;
    transform: translateY(-50%);
    height: 60%;
    width: 4px;
    background: linear-gradient(to bottom, var(--primary), var(--primary-dark));
    border-radius: 2px;
}

.terms-page h3 {
    font-size: 1.6rem;
    margin: 1.6rem 0 1rem;
    color: var(--primary);
}

.terms-page ul {
    padding-left: 1.7rem;
    margin: 1.6rem 0;
}

.terms-page li {
    margin-bottom: 0.9rem;
    line-height: 1.75;
    position: relative;
    padding-left: 1.2rem;
}

.terms-page li::before {
    content: "•";
    position: absolute;
    left: 0;
    color: var(--primary);
    font-weight: bold;
}

.terms-page strong {
    color: var(--primary-light);
}

.terms-page a {
    color: var(--primary-light);
    text-decoration: none;
    position: relative;
    transition: var(--transition);
}

.terms-page a::after {
    content: '';
    position: absolute;
    bottom: 2px;
    left: 0;
    width: 0;
    height: 1px;
    background: linear-gradient(to right, var(--primary), var(--primary-light));
    transition: var(--transition);
}

.terms-page a:hover {
    color: var(--primary-light);
}

.terms-page a:hover::after {
    width: 100%;
}
</style>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebPage",
  "@id": "https://abysstool.42web.io/terms",
  "url": "https://abysstool.42web.io/terms",
  "name": "Terms and Conditions - Abysstool",
  "isPartOf": {
    "@id": "https://abysstool.42web.io/#website"
  },
  "about": "Terms and Conditions",
  "description": "Read Abysstool’s Terms and Conditions to understand the rules and guidelines for using our free online tools.",
  "breadcrumb": {
    "@type": "BreadcrumbList",
    "itemListElement": [
      {
        "@type": "ListItem",
        "position": 1,
        "name": "Home",
        "item": "https://abysstool.42web.io/"
      },
      {
        "@type": "ListItem",
        "position": 2,
        "name": "Terms and Conditions",
        "item": "https://abysstool.42web.io/terms"
      }
    ]
  }
}
</script>
</head>
<body>
    <?php include 'header.php'; ?>

    <!-- Main Content -->
    <main class="main-content terms-page">
        <div class="content">
            <section class="hero animate-on-scroll">
                <h1>Terms and <span class="highlight">Conditions</span></h1>
                <p>Welcome to the abyss of digital privacy. By using AbyssTools, you agree to these terms that protect both your rights and our commitment to privacy.</p>
            </section>
            
            <section class="terms-section animate-on-scroll">
                <div class="terms-container">
                    <p><strong>Effective Date:</strong> July 29, 2025</p>
                    
                    <p>Welcome to AbyssTools (<a href="https://abysstools.42web.io" target="_blank">https://abysstools.42wwb.io</a>). By accessing or using this website, you agree to comply with and be bound by the following terms and conditions. If you do not agree with any part of these terms, please do not use this website.</p>
                    
                    <h2>1. Use of Tools</h2>
                    <p>AbyssTools provides privacy-focused utilities such as file encryptors, data erasers, password generators, and similar tools for informational and security purposes. While we aim to ensure the functionality of each tool, results may vary based on browser implementation. You are responsible for verifying outputs if they are used for critical security purposes.</p>
                    
                    <h2>2. Absolute Privacy Commitment</h2>
                    <p>We respect your privacy above all. AbyssTools does <strong>not collect, store, or process any personal information</strong> from users. You can use our tools anonymously without creating an account or providing any personal data. All processing happens locally in your browser whenever possible.</p>
                    
                    <h2>3. Third-Party Services</h2>
                    <p>Our service uses third-party services, including Google Analytics for traffic analysis and Google AdSense for advertisements. By using AbyssTool, you agree that we are not responsible for the data practices of these third parties. We strongly encourage you to read our detailed <a href="/Privacy">Privacy Policy</a>, which explains what data is collected by these services and how you can manage your preferences.</p>
                    
                    <h2>4. Intellectual Property</h2>
                    <p>All content, design, and tools on AbyssTools are the property of their respective owners. You may not copy, reproduce, or redistribute any content from this site without prior written permission. Our tools are provided for personal, non-commercial use only.</p>
                    
                    <h2>5. No Warranty</h2>
                    <p>AbyssTools is provided on an "as is" basis. We do not make warranties of any kind, either express or implied, regarding the operation of the site or the accuracy of the tools. While we strive for excellence in privacy protection, no digital tool can offer 100% security guarantees.</p>
                    
                    <h2>6. Limitation of Liability</h2>
                    <p>Under no circumstances shall AbyssTools be liable for any damages resulting from the use or inability to use the tools on this website. This includes, but is not limited to, direct, indirect, incidental, special, consequential or exemplary damages.</p>
                    
                    <h2>7. Changes to These Terms</h2>
                    <p>We may update these terms from time to time. Any changes will be posted on this page with an updated effective date. Continued use of AbyssTools after changes constitutes acceptance of the revised terms.</p>
                    
                    <h2>8. Jurisdiction</h2>
                    <p>These Terms shall be governed and construed in accordance with the laws of the jurisdiction where AbyssTools operates, without regard to its conflict of law provisions.</p>
                    
                    <h2>9. Contact Us</h2>
                    <p>If you have any questions about these Terms and Conditions, you may contact us via our <a href="contact.php">Contact Page</a>.</p>
                    
                    <p>By continuing to use AbyssTools, you acknowledge and agree to these terms. In the abyss of digital privacy, transparency is our guiding light.</p>
                </div>
            </section>
        </div>
    </main>
    
    <?php include 'footer.php'; ?>
    
    <!-- Live Background -->
    <canvas id="horror-canvas"></canvas>
    <div id="scan-lines"></div>
    <div id="glitch-overlay"></div>
    
    <script src="style.js"></script>
</body>
</html