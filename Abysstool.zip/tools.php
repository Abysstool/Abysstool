 <?php
// Set current year for footer
$currentYear = date("Y");
// Determine current page for navigation
$current_page = basename($_SERVER['PHP_SELF'], '.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include 'head.php'; ?> 
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="AbyssTools - All privacy tools with zero data collection. Explore our complete collection of secure, anonymous utilities.">
    <meta name="keywords" content="privacy tools, secure tools, all tools, complete collection, file encryptor, data eraser, password generator, IP masker, cookie cleaner, privacy tools collection">
    <meta name="author" content="AbyssTools Team">
    <meta name="robots" content="index, follow">
    <meta property="og:type" content="website">
    <meta property="og:title" content="All Tools - AbyssTools | Complete Privacy Toolkit">
    <meta property="og:description" content="Explore our complete collection of privacy tools with zero data collection. All tools work locally in your browser with no tracking.">
    <meta property="og:url" content="https://abysstool.42web.io/tools">
    <meta property="og:image" content="https://abysstool.42web.io/all-tool.png">
    <meta property="og:site_name" content="AbyssTools">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="All Tools - AbyssTools | Complete Privacy Toolkit">
    <meta name="twitter:description" content="Explore our complete collection of privacy tools with zero data collection. All tools work locally in your browser with no tracking.">
    <meta name="twitter:image" content="https://abysstool.42web.io/all-tool.png">
    <title>AbyssTool - Tools</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "CollectionPage",
  "@id": "https://abysstool.42web.io/tools",
  "url": "https://abysstool.42web.io/tools",
  "name": "All Tools - Abysstool",
  "isPartOf": {
    "@id": "https://abysstool.42web.io/#website"
  },
  "about": "List of free online tools including calculators, converters, and utilities.",
  "description": "Browse Abysstool’s full collection of free online tools. Quick access to calculators, converters, and utilities that save time and effort.",
  "breadcrumb": {
    "@type": "BreadcrumbList",
    "itemListElement": [
      {
        "@type": "ListItem",
        "position": 1,
        "name": "Home",
        "item": "https://abysstool.42web.io/"
      },
      {
        "@type": "ListItem",
        "position": 2,
        "name": "All Tools",
        "item": "https://abysstool.42web.io/tools"
      }
    ]
  }
}
</script>
</head>
<body>
    <?php include 'header.php'; ?>

    <!-- Main Content -->
    <main class="main-content">
        <div class="content">
            <section class="tools-section animate-on-scroll">
                <h2 class="section-title">All Privacy Tools</h2>
                <p style="margin-bottom: 2.2rem; max-width: 800px;">Explore our complete collection of privacy tools. All tools work locally in your browser with no data transmission.</p>
                
                <div class="tools-grid" id="all-tools-grid">
                    <!-- All tool cards will be populated by JavaScript -->
                </div>
            </section>
        </div>
    </main>
    
    <?php include 'footer.php'; ?>
    
    <!-- Live Background -->
    <canvas id="horror-canvas"></canvas>
    <div id="scan-lines"></div>
    <div id="glitch-overlay"></div>
    
    <script src="style.js"></script>
</body>
</html